<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>BRMS - Create New Report</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../assets/css/create.css">

</head>
<body>
<!-- PAGE FOR CREATE EMPLOYEE -->
<div class="createpage" id="createRepForm" data-role="page">    
        <form id="add_form" method="POST" enctype="" action="budget-function.php">
            <h4>Report of Collections and Deposits</h4>
            <div class="column">
            <label>Name of Barangay Treasurer:</label>
            <input type="text" class="form-control"autocomplete="off" name="nameadd">
            </div>
            <div class="column">
            <label>Date:</label>
            <input type="date" class="form-control" autocomplete="off" name="dateadd">
            </div>
            <div class="column">
            <label>Barangay:</label>
            <input type="text" class="form-control" autocomplete="off" name="barangayadd">
            </div>
            <div class="column mb-5">
            <label>RCD No.:</label>
            <input type="text" class="form-control" autocomplete="off" name="rcdadd">
            </div>

            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>

            <h6>A. Collections</h6>
            <div id="show_collect">
                <div class="row">
                    <div class="col-md-2 mb-3">
                    <input type="date" class="form-control" placeholder="Date" autocomplete="off" name="CDateadd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Number" autocomplete="off" name="CNumadd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Payor/BDC" autocomplete="off" name="CPayoradd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Nature of Collection" autocomplete="off" name="CCollectionadd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Amount" autocomplete="off" name="CAmountadd[]">
                    </div>
                    <div class="col-md-2 d-grid mb-5">
                    <button class="btn btn-success add_col_btn">Add More</button>
                    </div>
                </div>
            </div>

            <h6>B. Deposits</h6>
            <div id="show_deposit">
                <div class="row">
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Bank/Branch" autocomplete="off" name="DBankadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Reference" autocomplete="off" name="DRefadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Amount" autocomplete="off" name="DAmountadd[]">
                    </div>
                    <div class="col-md-3 mb-5 d-grid">
                    <button class="btn btn-success add_dep_btn">Add More</button>
                    </div>
                </div>
            </div>


            <h6>C. Accountability For Accountable Forms</h6>
            <div id="show_account">
                <div class="row">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Name of Forms and No." autocomplete="off" name="FormNadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Cash Tickets" autocomplete="off" name="Ticketadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Official Receipts" autocomplete="off" name="Receiptsadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-success add_acc_btn">Add More</button>
                    </div>
                </div>
            </div>

            
            <label><b>Beginning Balance</b></label>
            <div id="show_beginning">
                <div class="row">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Quantity" autocomplete="off" name="BeginQTYadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="From" autocomplete="off" name="BeginFromadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="To" autocomplete="off" name="BeginToadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-success add_begin_btn">Add More</button>
                    </div>
                </div>
            </div>

            
            <label><b>Receipt</b></label>
            <div id="show_receipt">
                <div class="row">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Quantity" autocomplete="off" name="ReceiptQTYadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="From" autocomplete="off" name="ReceiptFromadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="To" autocomplete="off" name="ReceiptToadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-success add_rec_btn">Add More</button>
                    </div>
                </div>
            </div>

            
            <label><b>Issued</b></label>
            <div id="show_issued">
                <div class="row">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Quantity" autocomplete="off" name="IssuedQTYadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="From" autocomplete="off" name="IssuedFromadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="To" autocomplete="off" name="IssuedToadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-success add_issue_btn">Add More</button>
                    </div>
                </div>
            </div>

            
            <label><b>Ending Balance</b></label>
            <div id="show_ending">
                <div class="row">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Quantity" autocomplete="off" name="EndingQTYadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="From" autocomplete="off" name="EndingFromadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="To" autocomplete="off" name="EndingToadd[]">
                    </div>
                    <div class="col-md-3 mb-5 d-grid">
                    <button class="btn btn-success add_end_btn">Add More</button>
                    </div>
                </div>
            </div>


            <h6>D. Accounting Entries</h6>
            <div id="show_accounting">
                <div class="row">
                <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Accounting Title" autocomplete="off" name="ATitleadd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Account Code" autocomplete="off" name="ACodeadd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Debit" autocomplete="off" name="Debitadd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Credit" autocomplete="off" name="Creditadd[]">
                    </div>
                    <div class="col-md-2 mb-5 d-grid">
                    <button class="btn btn-success add_account_btn">Add More</button>
                    </div>
                </div>
            </div>


            <div class="column mt-5">
            <label>Prepared By:</label>
            <input type="text" class="form-control"autocomplete="off" name="Preparedadd">
            </div>
            <div class="column mt-5">
            <label>Approved By:</label>
            <input type="text" class="form-control" autocomplete="off" name="Approvedadd">
            </div>

            <div class="footer">
            <button type="submit" name="save_budget" class="btn btn-success">Submit</button>
            <a href="budget-page.php">Close</a>
            </div>

        
        </form>
</div>






    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


    <script>
    $(document).ready(function(){
        $(".add_col_btn").click(function(e){
            e.preventDefault();
            $("#show_collect").prepend(`<div class="row append_item">
                <div class="col-md-2 mb-3">
                <input type="date" class="form-control" placeholder="Date" autocomplete="off" name="CDateadd[]">
                </div>
                <div class="col-md-2 mb-3">
                <input type="text" class="form-control" placeholder="Number" autocomplete="off" name="CNumadd[]">
                </div>
                <div class="col-md-2 mb-3">
                <input type="text" class="form-control" placeholder="Payor/BDC" autocomplete="off" name="CPayoradd[]">
                </div>
                <div class="col-md-2 mb-3">
                <input type="text" class="form-control" placeholder="Nature of Collection" autocomplete="off" name="CCollectionadd[]">
                </div>
                <div class="col-md-2 mb-3">
                <input type="text" class="form-control" placeholder="Amount" autocomplete="off" name="CAmountadd[]">
                </div>
                <div class="col-md-2 mb-3 d-grid">
                <button class="btn btn-danger remove_col_btn">Remove</button>
                </div>
            </div>`);
        });
        $(document).on('click', '.remove_col_btn', function(e){
            e.preventDefault();
            let row_item = $(this).parent().parent();
            $(row_item).remove();
        });

        $(".add_dep_btn").click(function(e){
            e.preventDefault();
            $("#show_deposit").prepend(`<div class="row append_item">
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Bank/Branch" autocomplete="off" name="DBankadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Reference" autocomplete="off" name="DRefadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Amount" autocomplete="off" name="DAmountadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-danger remove_dep_btn">Remove</button>
                    </div>
                </div>`);
        });
        $(document).on('click', '.remove_dep_btn', function(e){
            e.preventDefault();
            let row_item = $(this).parent().parent();
            $(row_item).remove();
        });

        $(".add_acc_btn").click(function(e){
            e.preventDefault();
            $("#show_account").prepend(`<div class="row append_item">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Name of Forms and No." autocomplete="off" name="FormNadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Cash Tickets" autocomplete="off" name="Ticketadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Official Receipts" autocomplete="off" name="Receiptsadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-danger remove_acc_btn">Remove</button>
                    </div>
                </div>`);
        });
        $(document).on('click', '.remove_acc_btn', function(e){
            e.preventDefault();
            let row_item = $(this).parent().parent();
            $(row_item).remove();
        });

        $(".add_begin_btn").click(function(e){
            e.preventDefault();
            $("#show_beginning").prepend(`<div class="row append_item">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Quantity" autocomplete="off" name="BeginQTYadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="From" autocomplete="off" name="BeginFromadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="To" autocomplete="off" name="BeginToadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-danger remove_begin_btn">Remove</button>
                    </div>
                </div>`);
        });
        $(document).on('click', '.remove_begin_btn', function(e){
            e.preventDefault();
            let row_item = $(this).parent().parent();
            $(row_item).remove();
        });

        $(".add_rec_btn").click(function(e){
            e.preventDefault();
            $("#show_receipt").prepend(`<div class="row append_item">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Quantity" autocomplete="off" name="ReceiptQTYadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="From" autocomplete="off" name="ReceiptFromadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="To" autocomplete="off" name="ReceiptToadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-danger remove_rec_btn">Remove</button>
                    </div>
                </div>`);
        });
        $(document).on('click', '.remove_rec_btn', function(e){
            e.preventDefault();
            let row_item = $(this).parent().parent();
            $(row_item).remove();
        });

        $(".add_issue_btn").click(function(e){
            e.preventDefault();
            $("#show_issued").prepend(`<div class="row append_item">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Quantity" autocomplete="off" name="IssuedQTYadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="From" autocomplete="off" name="IssuedFromadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="To" autocomplete="off" name="IssuedToadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-danger remove_issue_btn">Remove</button>
                    </div>
                </div>`);
        });
        $(document).on('click', '.remove_issue_btn', function(e){
            e.preventDefault();
            let row_item = $(this).parent().parent();
            $(row_item).remove();
        });

        $(".add_end_btn").click(function(e){
            e.preventDefault();
            $("#show_ending").prepend(`<div class="row append_item">
                <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="Quantity" autocomplete="off" name="EndingQTYadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="From" autocomplete="off" name="EndingFromadd[]">
                    </div>
                    <div class="col-md-3 mb-3">
                    <input type="text" class="form-control" placeholder="To" autocomplete="off" name="EndingToadd[]">
                    </div>
                    <div class="col-md-3 mb-3 d-grid">
                    <button class="btn btn-danger remove_end_btn">Remove</button>
                    </div>
                </div>`);
        });
        $(document).on('click', '.remove_end_btn', function(e){
            e.preventDefault();
            let row_item = $(this).parent().parent();
            $(row_item).remove();
        });

        $(".add_account_btn").click(function(e){
            e.preventDefault();
            $("#show_accounting").prepend(`<div class="row append_item">
                <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Accounting Title" autocomplete="off" name="ATitleadd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Account Code" autocomplete="off" name="ACodeadd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Debit" autocomplete="off" name="Debitadd[]">
                    </div>
                    <div class="col-md-2 mb-3">
                    <input type="text" class="form-control" placeholder="Credit" autocomplete="off" name="Creditadd[]">
                    </div>
                    <div class="col-md-2 mb-3 d-grid">
                    <button class="btn btn-danger remove_account_btn">Remove</button>
                    </div>
                </div>`);
        });
        $(document).on('click', '.remove_account_btn', function(e){
            e.preventDefault();
            let row_item = $(this).parent().parent();
            $(row_item).remove();
        });






    });
    </script>


 </body>
</html>