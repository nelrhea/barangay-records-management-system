<?php

session_start();
$conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

if(isset($_POST['save_budget']))
{
    $userName = $_SESSION['username'];
    
    $name = $_POST['nameadd'];
    $date = $_POST['dateadd'];
    $barangay = $_POST['barangayadd'];
    $rcd = $_POST['rcdadd'];

    $cdate = $_POST['CDateadd'];
    $cnum = $_POST['CNumadd'];
    $cpayor = $_POST['CPayoradd'];
    $ccollect = $_POST['CCollectionadd'];
    $camount = $_POST['CAmountadd'];
    $dbank = $_POST['DBankadd'];
    $dref = $_POST['DRefadd'];
    $damount = $_POST['DAmountadd'];
    $form = $_POST['FormNadd'];
    $ticket = $_POST['Ticketadd'];
    $receipt = $_POST['Receiptsadd'];
    $bqty = $_POST['BeginQTYadd'];
    $bfrom = $_POST['BeginFromadd'];
    $bto = $_POST['BeginToadd'];
    $rqty = $_POST['ReceiptQTYadd'];
    $rfrom = $_POST['ReceiptFromadd'];
    $rto = $_POST['ReceiptToadd'];
    $iqty = $_POST['IssuedQTYadd'];
    $ifrom = $_POST['IssuedFromadd'];
    $ito = $_POST['IssuedToadd'];
    $eqty = $_POST['EndingQTYadd'];
    $efrom = $_POST['EndingFromadd'];
    $eto = $_POST['EndingToadd'];
    $title = $_POST['ATitleadd'];
    $code = $_POST['ACodeadd'];
    $debit = $_POST['Debitadd'];
    $credit = $_POST['Creditadd'];
    $prepared = $_POST['Preparedadd'];
    $approved = $_POST['Approvedadd'];
 
    


    foreach($cdate as $index => $cdates)
    {
        $c_date = $cdates;
        $c_num = $cnum[$index];
        $c_payor = $cpayor[$index];
        $c_collect = $ccollect[$index];
        $c_amount = $camount[$index];
        $d_bank = $dbank[$index];
        $d_ref = $dref[$index];
        $d_amount = $damount[$index];
        $o_form = $form[$index];
        $o_ticket = $ticket[$index];
        $o_receipt = $receipt[$index];
        $b_qty = $bqty[$index];
        $b_from = $bfrom[$index];
        $b_to = $bto[$index];
        $r_qty = $rqty[$index];
        $r_from = $rfrom[$index];
        $r_to = $rto[$index];
        $i_qty = $iqty[$index];
        $i_from = $ifrom[$index];
        $i_to = $ito[$index];
        $e_qty = $eqty[$index];
        $e_from = $efrom[$index];
        $e_to = $eto[$index];
        $a_title = $title[$index];
        $a_code = $code[$index];
        $a_debit = $debit[$index];
        $a_credit = $credit[$index];
        
        

        $query = "INSERT INTO budget (Treasurer_name, Date_rec, Brg_name, Rcd_id, Cdate, Cnum, Cpayor, Ccollection, Camount, Dbank, Dref, Damount, Form_name, Cash_ticket, Official_receipt, Beginqty, Beginfrom, Beginto, Receiptqty, Receiptfrom, Receiptto, Issueqty, Issuefrom, Issueto, Endqty, Endfrom, Endto, Account_title, Account_code, Debit, Credit, Prepared, Approved) VALUES ('$name', '$date', '$barangay', '$rcd', '$c_date', '$c_num', '$c_payor', '$c_collect', '$c_amount', '$d_bank', '$d_ref', '$d_amount', '$o_form', '$o_ticket', '$o_receipt', '$b_qty', '$b_from', '$b_to', '$r_qty', '$r_from', '$r_to', '$i_qty', '$i_from', '$i_to', '$e_qty', '$e_from', '$e_to', '$a_title', '$a_code', '$a_debit', '$a_credit', '$prepared', '$approved')";

        $query_run = mysqli_query($conn, $query);

        if ($query_run) {
            $_SESSION['status'] = "Successfully Saved!";
            header('Location: budget-page.php');
        } 
        else 
        {
            $_SESSION['status'] = "Not Saved: " . mysqli_error($conn); 
            header('Location: budget-page.php');
        }
    }
    
    $action = "Add Budget"; 
    $timestamp = date("Y-m-d H:i:s");

    $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
    mysqli_query($conn, $logQuery);
}



//delete
if (isset($_GET['RCDid'])) {
    
    $rcdid = $_GET['RCDid'];
    $userName = $_SESSION['username'];
    $delete_query = "DELETE FROM budget WHERE Rcd_id = '$rcdid'";
    $result = mysqli_query($conn, $delete_query);
    
    
    if ($result) {
        header("Location: budget-page.php"); // Redirect back to your original page after deletion
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    
    $action = "Delete Budget"; 
    $timestamp = date("Y-m-d H:i:s");

    $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
    mysqli_query($conn, $logQuery);
}
mysqli_close($conn);




?>