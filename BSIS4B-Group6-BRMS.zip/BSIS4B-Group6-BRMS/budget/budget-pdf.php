<?php
require('../fpdf186/fpdf.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);


// Establish a database connection (example with MySQLi)
$mysqli = new mysqli("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

// Check the connection
if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

if (isset($_GET['RCDid'])) {
    $budget = urldecode($_GET['RCDid']);

    // Fetch data from the database for the specified Rcd_id
    $query = "SELECT Treasurer_name, Date_rec, Brg_name, Rcd_id, Cdate, Cnum, Cpayor, Ccollection, Camount, Dbank, Dref, Damount, Form_name, Cash_ticket, Official_receipt, Beginqty, Beginfrom, Beginto, Receiptqty, Receiptfrom, Receiptto, Issueqty, Issuefrom, Issueto, Endqty, Endfrom, Endto, Account_title, Account_code, Debit, Credit, Prepared, Approved 
              FROM budget 
              WHERE Rcd_id = ?";
    
    $stmt = $mysqli->prepare($query);

    // Check if the statement was prepared successfully
    if (!$stmt) {
        die('Error preparing statement: ' . $mysqli->error);
    }

    $stmt->bind_param("s", $budget);
    $stmt->execute();
    $result = $stmt->get_result();

    $pdf = new FPDF('P', 'mm', 'Legal');
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 14);

    $pdf->Cell(195, 10, 'Report of Collections and Deposits', 1, 1, 'C');

    $pdf->SetFont('Arial', '', 11);

    // Check if there are rows with the specified Rcd_id
    if ($result->num_rows > 0) {
        // Initialize variables to hold consolidated data for the same Rcd_id
        $consolidatedData = array();

        // Loop through all rows with the same Rcd_id and consolidate the data
        while ($row = $result->fetch_assoc()) {
            // Check if we already have data for the current Rcd_id
            if (!isset($consolidatedData[$row['Rcd_id']])) {
                $consolidatedData[$row['Rcd_id']] = array(
                    'Treasurer_name' => $row['Treasurer_name'],
                    'Date_rec' => $row['Date_rec'],
                    'Brg_name' => $row['Brg_name'],
                    'Approved' => $row['Approved'],
                    'Prepared' => $row['Prepared'],
                    'Cdata' => array(),
                );
            }

            // Add the collection row data to the consolidated data
            $consolidatedData[$row['Rcd_id']]['Cdata'][] = array(
                'Cdate' => $row['Cdate'],
                'Cnum' => $row['Cnum'],
                'Cpayor' => $row['Cpayor'],
                'Ccollection' => $row['Ccollection'],
                'Camount' => $row['Camount'],
                'Dbank' => $row['Dbank'],
                'Dref' => $row['Dref'],
                'Damount' => $row['Damount'],
                'Beginqty' => $row['Beginqty'],
                'Beginfrom' => $row['Beginfrom'],
                'Beginto' => $row['Beginto'],
                'Receiptqty' => $row['Receiptqty'],
                'Receiptfrom' => $row['Receiptfrom'],
                'Receiptto' => $row['Receiptto'],
                'Issueqty' => $row['Issueqty'],
                'Issuefrom' => $row['Issuefrom'],
                'Issueto' => $row['Issueto'],
                'Endqty' => $row['Endqty'],
                'Endfrom' => $row['Endfrom'],
                'Endto' => $row['Endto'],
                'Cash_ticket' => $row['Cash_ticket'],
                'Account_title' => $row['Account_title'],
                'Account_code' => $row['Account_code'],
                'Debit' => $row['Debit'],
                'Credit' => $row['Credit'],

            );
        }

        // Loop through the consolidated data and display it in the PDF
        foreach ($consolidatedData as $Rcd_id => $data) {
            $pdf->MultiCell(195, 10, '          Name of Treasurer: ' . $data['Treasurer_name'] . '                                                                Date: ' . $data['Date_rec'] . "\n          Barangay: " . $data['Brg_name'] . '                                                                      RCD Number: ' . $Rcd_id, 1, 'L');

            // Collection column
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(195, 5, 'A. COLLECTIONS', 1, 1, 'L');
            $pdf->SetFont('Arial', '', 11);
            $pdf->Cell(60, 5, 'Official Receipt/RCR', 1, 0, 'C');
            $pdf->Cell(45, 10, 'Payor/DBC', 1, 0, 'C');
            $pdf->Cell(45, 10, 'Nature of Collection', 1, 0, 'C');
            $pdf->Cell(45, 10, 'Amount', 1, 0, 'C');
            $pdf->SetY($pdf->GetY() + 5);
            $pdf->Cell(30, 5, 'Date', 1, 0, 'C');
            $pdf->Cell(30, 5, 'Number', 1, 1, 'C');

            // Collection rows for the current Rcd_id
            foreach ($data['Cdata'] as $collectionRow) {
                $pdf->Cell(30, 5, $collectionRow['Cdate'], 1, 0, 'C');
                $pdf->Cell(30, 5, $collectionRow['Cnum'], 1, 0, 'C');
                $pdf->Cell(45, 5, $collectionRow['Cpayor'], 1, 0, 'C');
                $pdf->Cell(45, 5, $collectionRow['Ccollection'], 1, 0, 'C');
                $pdf->Cell(45, 5, $collectionRow['Camount'], 1, 1, 'C');
            }
            $pdf->Cell(195, 5, 'TOTAL', 1, 0, 'L');
            $pdf->SetX($pdf->GetX() - 45);
            $pdf->Cell(45, 5, '27,700.00', 0, 1, 'C');

            // Deposit column
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(195, 5, 'B. DEPOSITS', 1, 1, 'L');
            $pdf->SetFont('Arial', '', 11);
            $pdf->Cell(105, 5, 'Bank/Branch', 1, 0, 'C');
            $pdf->Cell(45, 5, 'Reference', 1, 0, 'C');
            $pdf->Cell(45, 5, 'Amount', 1, 1, 'C');
            $totalDamount = 0;

            //Deposit rows
            foreach ($data['Cdata'] as $depositRow) {
                $pdf->Cell(105, 5, $depositRow['Dbank'], 1, 0, 'C');
                $pdf->Cell(45, 5, $depositRow['Dref'], 1, 0, 'C');
                $pdf->Cell(45, 5, $depositRow['Damount'], 1, 1, 'C');

                $totalDamount += floatval($depositRow['Damount']);
            }
            $pdf->Cell(195, 5, 'TOTAL', 1, 0, 'L');
            $pdf->SetX($pdf->GetX() - 45);
            $pdf->Cell(45, 5, $totalDamount, 0, 1, 'C');

            // Accountable Forms column
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(195, 5, 'C. ACCOUNTABILITY FOR ACCOUNTABLE FORMS', 1, 1, 'L');
            $pdf->SetFont('Arial', '', 11);
            $pdf->Cell(43, 5, 'Name of Form and No.', 1, 0, 'C');
            $pdf->Cell(38, 5, 'Beginning Balance', 1, 0, 'C');
            $pdf->Cell(38, 5, 'Receipt', 1, 0, 'C');
            $pdf->Cell(38, 5, 'Issued', 1, 0, 'C');
            $pdf->Cell(38, 5, 'Ending Balance', 1, 1, 'C');
            $pdf->SetFont('Arial', '', 8);
            $pdf->SetX($pdf->GetX() + 43);
            $pdf->Cell(6, 10, 'QTY', 1, 0, 'C');
            $pdf->Cell(32, 5, 'Inclusive Serial No.', 1, 0, 'C');
            $pdf->Cell(6, 10, 'QTY', 1, 0, 'C');
            $pdf->Cell(32, 5, 'Inclusive Serial No.', 1, 0, 'C');
            $pdf->Cell(6, 10, 'QTY', 1, 0, 'C');
            $pdf->Cell(32, 5, 'Inclusive Serial No.', 1, 0, 'C');
            $pdf->Cell(6, 10, 'QTY', 1, 0, 'C');
            $pdf->Cell(32, 5, 'Inclusive Serial No.', 1, 1, 'C');
            $pdf->SetX($pdf->GetX() + 49);
            $pdf->Cell(16, 5, 'From', 1, 0, 'C');
            $pdf->Cell(16, 5, 'To', 1, 0, 'C');
            $pdf->SetX($pdf->GetX() + 6);
            $pdf->Cell(16, 5, 'From', 1, 0, 'C');
            $pdf->Cell(16, 5, 'To', 1, 0, 'C');
            $pdf->SetX($pdf->GetX() + 6);
            $pdf->Cell(16, 5, 'From', 1, 0, 'C');
            $pdf->Cell(16, 5, 'To', 1, 0, 'C');
            $pdf->SetX($pdf->GetX() + 6);
            $pdf->Cell(16, 5, 'From', 1, 0, 'C');
            $pdf->Cell(16, 5, 'To', 1, 1, 'C');

            foreach ($data['Cdata'] as $accountableRow) {
                $pdf->SetX($pdf->GetX() + 43);
                $pdf->Cell(6, 5, $accountableRow['Beginqty'], 1, 0, 'C');
                $pdf->Cell(16, 5, $accountableRow['Beginfrom'], 1, 0, 'C');
                $pdf->Cell(16, 5, $accountableRow['Beginto'], 1, 0, 'C');
                $pdf->Cell(6, 5, $accountableRow['Receiptqty'], 1, 0, 'C');
                $pdf->Cell(16, 5, $accountableRow['Receiptfrom'], 1, 0, 'C');
                $pdf->Cell(16, 5, $accountableRow['Receiptto'], 1, 0, 'C');
                $pdf->Cell(6, 5, $accountableRow['Issueqty'], 1, 0, 'C');
                $pdf->Cell(16, 5, $accountableRow['Issuefrom'], 1, 0, 'C');
                $pdf->Cell(16, 5, $accountableRow['Issueto'], 1, 0, 'C');
                $pdf->Cell(6, 5, $accountableRow['Endqty'], 1, 0, 'C');
                $pdf->Cell(16, 5, $accountableRow['Endfrom'], 1, 0, 'C');
                $pdf->Cell(16, 5, $accountableRow['Endto'], 1, 1, 'C');
            }

            $pdf->SetY($pdf->GetY() - 30);
            $pdf->Cell(43, 5, 'With Money Value:', 1, 1, 'C');
            $pdf->Cell(43, 5, 'Cash Ticket', 1, 0, 'C');

            foreach ($data['Cdata'] as $ticketRow) {
                $pdf->SetY($pdf->GetY() + 5);
                $pdf->Cell(43, 5, $ticketRow['Cash_ticket'], 1, 0, 'C');
            }

            // Certification column
            $pdf->Ln();
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(195, 10, 'D. CERTIFICATION', 1, 1, 'L');
            $pdf->SetFont('Arial', '', 9);
            $pdf->MultiCell(195, 5,'I hereby certify that this Report of Collections and Deposits; and Accountable Forms including supporting documents are true and correct.   ' . "\n                                     ". $data['Treasurer_name'] . '                                                                              ' . $data['Date_rec'] . "\n                                  ____________________" . '                                                          ____________________ '."\n                                       Barangay Treasurer " . '                                                                           Date ', 1, 'L');

            //ACCOUNTING ENTRIES
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(195, 5, 'E. ACCOUNTING ENTRIES', 1, 1, 'L');
            $pdf->SetFont('Arial', '', 9);
            $pdf->Cell(51, 5, 'Account Title', 1, 0, 'C');
            $pdf->Cell(48, 5, 'Account Code', 1, 0, 'C');
            $pdf->Cell(48, 5, 'Debit', 1, 0, 'C');
            $pdf->Cell(48, 5, 'Credit', 1, 1, 'C');

            foreach ($data['Cdata'] as $accountRow) {
                $pdf->Cell(51, 5, $accountRow['Account_title'], 1, 0, 'C');
                $pdf->Cell(48, 5, $accountRow['Account_code'], 1, 0, 'C');
                $pdf->Cell(48, 5, $accountRow['Debit'], 1, 0, 'C');
                $pdf->Cell(48, 5, $accountRow['Credit'], 1, 1, 'C');
            }

            $pdf->MultiCell(195, 5, '                                              Prepared by:'.'                                                                                         Approved by:'."\n                                         ". $data['Prepared'] .'                                                                                 '. $data['Approved']."\n                              _____________________________".'                                                _____________________________'.'                                                                    Barangay Bookeeper'.'                                                                     City/Municipal Accountant', 1, 'L');

            








        }
    } else {
        echo "No data found for the specified RCDid.";
    }

    $pdf->Output();
    $mysqli->close();
} else {
    echo "Report Collections and Deposits not provided in the URL.";
}
?>
