<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BRMS - Manage Report</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/budget.css">

        <?php include '../includes/header.php'; ?>
        <?php include '../includes/sidebar.php'; ?>

</head>
<body>
    
    <?php
session_start();
?>

    <div class="budgetpage">
        <div id="budgetList" class="budgetForm" data-role="page">
            <h4>Manage Report of Collections and Deposits</h4>
        
            <!--button to open modal-->
            <div class="container">                 
                <a type="button" href="create-form.php" id="btnCreate" reload="true" data-transition="slide">Create New Budget Report</a>
            </div>
        </div>

            <!--view budget table-->
        <div class="table-container">
            <table class="budgettable" id="budgettable" data-role="table" border="1" cellspacing="5">
                <thead class="table">
                    <tr>
                        <th scope="col">RCD Number</th>
                        <th scope="col">Date Recorded</th>
                        <th scope="col">Prepared By</th>
                        <th scope="col">Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");
                        $query = "SELECT Rcd_id, Date_rec, Prepared FROM budget GROUP BY Rcd_id";
                        $query_run = mysqli_query($conn, $query);

                        if (mysqli_num_rows($query_run) > 0) {
                            while ($row = mysqli_fetch_assoc($query_run)) {
                                $rcdid = $row['Rcd_id'];
                                $date = $row['Date_rec'];
                                $prepared = $row['Prepared'];
                                ?>
                                    <tr>
                                        <td class="RCDid"><?php echo $rcdid; ?></td>
                                        <td><?php echo $date; ?></td>
                                        <td><?php echo $prepared; ?></td>
                                        <td>
                                            <a href="budget-pdf.php?RCDid=<?php echo $rcdid; ?>" class="fas fa-file-pdf text-success ml-4" target="_blank" title="PDF File"></a>
                                            <a href="budget-function.php?RCDid=<?php echo $rcdid; ?>" class="fas fa-trash-alt text-danger ml-2 delete_btn" title="Delete"></a>
                                        </td>
                                    </tr>
                                
                            <?php
                            }
                        }
                        else
                        {
                            echo "<h5>No Record Found</h5>";
                        }
                        ?>
                    
                </tbody>

            </table>
            
        </div>


    </div>

        


    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>



 </body>
</html>