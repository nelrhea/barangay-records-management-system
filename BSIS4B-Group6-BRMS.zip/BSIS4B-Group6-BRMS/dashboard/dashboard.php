<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BRMS - Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">


        <?php include '../includes/header.php'; ?>
        <?php include '../includes/sidebar.php'; ?>
</head>
<body>
    <?php
session_start();
?>

<div class="dashboardpage">
    <div id="dashboardList" class="dashboardForm" data-role="page">
          <h4>Dashboard</h4>

        <?php
            $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

            $sql = "SELECT COUNT(*) AS count FROM resident";
            $result = $conn->query($sql);
            $data = $result->fetch_assoc();

            $populationcount = $data['count'];

            $conn->close();
        ?>
        <div class="card1">
            <div class="card-content">
                <span class="fas fa-users text-primary"></span>
                <h4>Population</h4>
                <h6><?php echo $populationcount; ?></h6>
                <p>Total Population</p>
            </div>
        </div>
        <?php
            $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

            // Count total male residents
            $sqlMale = "SELECT COUNT(*) AS male_count FROM resident WHERE gender = 'Male'";
            $resultMale = $conn->query($sqlMale);
            $dataMale = $resultMale->fetch_assoc();
            $maleCount = $dataMale['male_count'];

            // Count total female residents
            $sqlFemale = "SELECT COUNT(*) AS female_count FROM resident WHERE gender = 'Female'";
            $resultFemale = $conn->query($sqlFemale);
            $dataFemale = $resultFemale->fetch_assoc();
            $femaleCount = $dataFemale['female_count'];


            $conn->close();
        ?>
        <div class="card2">
            <div class="card-content">
                <span class="fa-solid fa-house-chimney text-primary"></span>
                <h4>Residents</h4>
                <h6>Male: <?php echo $maleCount; ?>
                <br>
                Female: <?php echo $femaleCount; ?></h6>
                <p>Total Residents</p>
            </div>
        </div>

        <?php
            $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

            $sql = "SELECT COUNT(*) AS count FROM blotter";
            $result = $conn->query($sql);
            $data = $result->fetch_assoc();

            $blottercount = $data['count'];

            $conn->close();
        ?>
        <div class="card3">
            <div class="card-content">
                <span class="fa-solid fa-folder-open text-primary"></span>
                <h4>Blotter</h4>
                <h6><?php echo $blottercount; ?></h6>
                <p>Total Blotter Recorded</p>
            </div>
        </div>
        <?php
            $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

           $sql = "SELECT COUNT(DISTINCT Rcd_id) AS count FROM budget";
            $result = $conn->query($sql);
            $data = $result->fetch_assoc();

            $budgetcount = $data['count'];

            $conn->close();
        ?>
        
        <div class="card4">
            <div class="card-content">
                <span class="fa-solid fa-coins text-primary"></span>
                <h4>Revenue</h4>
                <h6><?php echo $budgetcount; ?></h6>
                <p>Total Revenue Report</p>
            </div>
        </div>


        <?php
            $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

            $sql = "SELECT COUNT(*) AS count FROM requests";
            $result = $conn->query($sql);
            $data = $result->fetch_assoc();

            $requestcount = $data['count'];

            $sqlApproved = "SELECT COUNT(*) AS approved_count FROM requests WHERE approval_status = 'Approved'";
            $resultApproved = $conn->query($sqlApproved);
            $dataApproved = $resultApproved->fetch_assoc();
            $approvedCount = $dataApproved['approved_count'];

            $sqlDispproved = "SELECT COUNT(*) AS disapproved_count FROM requests WHERE approval_status = 'Disapproved'";
            $resultDispproved = $conn->query($sqlDispproved);
            $dataDispproved = $resultDispproved->fetch_assoc();
            $disapprovedCount = $dataDispproved['disapproved_count'];

            $sqlPending= "SELECT COUNT(*) AS pending_count FROM requests WHERE approval_status = 'Pending'";
            $resultPending = $conn->query($sqlPending);
            $dataPending = $resultPending->fetch_assoc();
            $pendingCount = $dataPending['pending_count'];

            $conn->close();


        ?>
        <div class="card5">
            <div class="card-content">
                <span class="fas fa-file-alt text-primary"></span>
                <h4>Certificates</h4>
                <h6>Approved: <?php echo $approvedCount; ?>
                <br>
                Disapproved: <?php echo $disapprovedCount; ?>
                <br>
                Pending: <?php echo $pendingCount; ?></h6>
                <p>Total Certificate Recorded <?php echo $requestcount; ?></p>
            </div>
        </div>
        
        
         <?php
            $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

           $sql = "SELECT COUNT(*) AS count FROM users";
            $result = $conn->query($sql);
            $data = $result->fetch_assoc();

            $usercount = $data['count'];

            $conn->close();
        ?>
        
        <div class="card6">
            <div class="card-content">
                <span class="fa-solid fa-user text-primary"></span>
                <h4>User's</h4>
                <h6><?php echo $usercount; ?></h6>
                <p>Total User's Registered</p>
            </div>
        </div>


    
        
</div>



    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>




    </body>
</html>