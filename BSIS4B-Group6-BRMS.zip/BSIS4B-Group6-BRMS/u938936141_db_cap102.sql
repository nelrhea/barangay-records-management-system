-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 20, 2023 at 12:24 PM
-- Server version: 10.5.19-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u938936141_db_cap102`
--

-- --------------------------------------------------------

--
-- Table structure for table `blotter`
--

CREATE TABLE `blotter` (
  `report_id` int(11) NOT NULL,
  `blotter_id` int(11) NOT NULL,
  `recorded` date DEFAULT NULL,
  `complainant` varchar(255) DEFAULT NULL,
  `Cage` int(11) DEFAULT NULL,
  `Caddress` varchar(255) DEFAULT NULL,
  `Ccontact` int(11) DEFAULT NULL,
  `complainee` varchar(255) DEFAULT NULL,
  `Page` int(11) DEFAULT NULL,
  `Paddress` varchar(255) DEFAULT NULL,
  `Pcontact` int(11) DEFAULT NULL,
  `complaint` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `incidence` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `blotter`
--

INSERT INTO `blotter` (`report_id`, `blotter_id`, `recorded`, `complainant`, `Cage`, `Caddress`, `Ccontact`, `complainee`, `Page`, `Paddress`, `Pcontact`, `complaint`, `action`, `status`, `incidence`) VALUES
(2, 202309302, '2023-09-30', 'John Isip', 40, 'Cangatba', 987654321, 'Josh Mautak', 35, 'Cangatba', 912345678, 'Noise complaint', 'meeting in barangay', 'ongiong', 'Cangatba');

-- --------------------------------------------------------

--
-- Table structure for table `budget`
--

CREATE TABLE `budget` (
  `id` int(11) NOT NULL,
  `Rcd_id` varchar(255) DEFAULT NULL,
  `Treasurer_name` varchar(255) DEFAULT NULL,
  `Date_rec` varchar(255) DEFAULT NULL,
  `Brg_name` varchar(255) DEFAULT NULL,
  `Cdate` date DEFAULT NULL,
  `Cnum` varchar(255) DEFAULT NULL,
  `Cpayor` varchar(255) DEFAULT NULL,
  `Ccollection` varchar(255) DEFAULT NULL,
  `Camount` varchar(255) DEFAULT NULL,
  `Dbank` varchar(255) DEFAULT NULL,
  `Dref` varchar(255) DEFAULT NULL,
  `Damount` varchar(255) DEFAULT NULL,
  `Form_name` varchar(255) DEFAULT NULL,
  `Cash_ticket` varchar(255) DEFAULT NULL,
  `Official_receipt` varchar(255) DEFAULT NULL,
  `Beginqty` varchar(255) DEFAULT NULL,
  `Beginfrom` varchar(255) DEFAULT NULL,
  `Beginto` varchar(255) DEFAULT NULL,
  `Receiptqty` varchar(255) DEFAULT NULL,
  `Receiptfrom` varchar(255) DEFAULT NULL,
  `Receiptto` varchar(255) DEFAULT NULL,
  `Issueqty` varchar(255) DEFAULT NULL,
  `Issuefrom` varchar(255) DEFAULT NULL,
  `Issueto` varchar(255) DEFAULT NULL,
  `Endqty` varchar(255) DEFAULT NULL,
  `Endfrom` varchar(255) DEFAULT NULL,
  `Endto` varchar(255) DEFAULT NULL,
  `Account_title` varchar(255) DEFAULT NULL,
  `Account_code` varchar(255) DEFAULT NULL,
  `Debit` varchar(255) DEFAULT NULL,
  `Credit` varchar(255) DEFAULT NULL,
  `Prepared` varchar(255) DEFAULT NULL,
  `Approved` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `budget`
--

INSERT INTO `budget` (`id`, `Rcd_id`, `Treasurer_name`, `Date_rec`, `Brg_name`, `Cdate`, `Cnum`, `Cpayor`, `Ccollection`, `Camount`, `Dbank`, `Dref`, `Damount`, `Form_name`, `Cash_ticket`, `Official_receipt`, `Beginqty`, `Beginfrom`, `Beginto`, `Receiptqty`, `Receiptfrom`, `Receiptto`, `Issueqty`, `Issuefrom`, `Issueto`, `Endqty`, `Endfrom`, `Endto`, `Account_title`, `Account_code`, `Debit`, `Credit`, `Prepared`, `Approved`) VALUES
(1, '234567', 'Rodolfo M. Magno', '2023-09-17', 'Cangatba Porac Pampanga', '2023-09-17', '09786532671', 'N/A', 'N/A', '7000', 'China bank', 'N/A', '3000', 'Form 1', '3000', 'Last week', 'Depends', 'Nowhere', 'Anywhere', 'Depends', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Much', 'Depends', 'Secret', 'Myaccount', '3242', '765432', '987654', 'Admin1', 'Admin2'),
(2, '456789', 'Jennard C David', '2023-09-16', 'Cangatba Poac Pampanga', '2023-09-16', '32', 'N/A', 'N/A', '3000', 'GRBank', 'N/A', '2000', 'Depends', '4000', 'Yesterday', '3000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Own Account', '456787', '654345', '765456', 'Admin1', 'Admin2'),
(3, '567876', 'Asiong A. Salonga', '2023-09-17', 'Cangatba Poac Pampanga', '2023-09-17', '22', 'N/A', 'N/A', '4000', 'BOF', 'Idk', '2000', 'Secret', '2000', 'N/A', '3400', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Money', 'Idk', 'Idk', '2500', 'Idk', 'Idk', 'Secret Account', '456765', '3456735', '4536365', 'Admin2', 'Admin1'),
(4, '5678765', 'Kathlyn C. Magsaysay', '2023-09-18', 'Cangatba Poac Pampanga', '2023-09-18', '44', 'N/A', 'N/A', '4500', 'MetroBank', 'Idk', '3500', 'Secret', '1500', 'Yesterday', '3500', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2300', 'Idk', 'Idk', 'Own Account', '34545', '3572578', '8471347', 'Admin2', 'Admin1'),
(5, '4587644', 'Jaypee Y. Santos', '2023-09-16', 'Cangatba Poac Pampanga', '2023-09-16', '11', 'Idk', 'Idk', '3000', 'China Bank', 'Idk', '3000', 'Idk', '1300', 'Now', '3000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '1000', 'Idk', 'Idk', 'My Account', '345654', '8765432', '2345677', 'Admin1', 'Admin2'),
(6, '876543', 'Cindy S. Bilog', '2023-09-18', 'Cangatba Poac Pampanga', '2023-09-18', '25', 'N/A', 'N/A', '4000', 'Metro Bank', 'Idk', '3000', '', '', '', '4000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'My Account', '634623', '574833487', '53789965', 'Admin1', 'Admin2'),
(7, '5787654', 'Reyniel M. Contis', '2023-09-16', 'Cangatba Poac Pampanga', '2023-09-16', '33', 'N/A', 'N/A', '4300', 'China Bank', 'Idk', '5000', 'Secret', 'Much', 'Now', '5000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '3000', 'Idk', 'Idk', 'My Account', '876567', '876543234', '765456789', 'Admin1', 'Admin2'),
(8, '647382', 'Jayvee M. Santos', '2023-09-17', 'Cangatba Poac Pampanga', '2023-09-17', '11', 'N/A', 'N/A', 'N/A', 'BOF', 'Idk', '4000', 'Secret', '4500', 'Now', '4000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2000', 'Idk', 'Idk', 'My account', '74666', '748383929', '635342528', 'Admin2', 'Admin1'),
(9, '7646378', 'Ronald A. Bognot', '2023-09-17', 'Cangatba Poac Pampanga', '2023-09-17', '13', 'N/A', 'N/A', '6000', 'China Bank', 'N/A', '5000', '', '3000', 'Now', '6000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2500', 'Idk', 'Idk', 'My Account', '356478', '57385893', '38572598', 'Admin2', 'Admin1'),
(10, '5678976', 'Almina C. Cura', '2023-09-19', 'Cangatba Poac Pampanga', '2023-09-19', '54', 'N/A', 'N/A', '7000', 'GR Bank', 'Idk', '6000', 'Secret', '3000', 'Now', '7000', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', 'My Account', '748390', '564786789', '56478998', 'Admin2', 'Admin1'),
(11, '647382', 'Arthur B. Nery', '2023-07-17', 'Cangatba Poac Pampanga', '2023-07-17', '9', 'N/A', 'N/A', '8000', 'China Bank', 'Idk', '7000', 'Secret', '3000', 'Now', '', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', 'My Account', '56743', '647389078', '087654567', 'Admin2', 'Admin1'),
(12, '767883', 'Michelle K. Hicban', '2023-10-17', 'Cangatba Poac Pampanga', '2023-10-17', '65', 'N/A', 'N/A', '4500', 'Metro bank', 'Idk', '2000', 'Secret', '3000', 'Now', '4500', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', 'My Account', '432678', '4365438765', '5432876543', 'Admin1', 'Admin2'),
(13, '678965', 'Kent V. Mayami', '2023-06-13', 'Cangatba Porac Pampanga', '2023-06-13', '56', 'N/A', 'N/A', '3000', 'BOF', 'Idk', '3000', 'Secret', '3000', 'Now', '', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', 'My Account', '584930', '584967393', '576908475', 'Admin1', 'Admin2'),
(14, '432678', 'Kimene A. Sikat', '2023-02-27', 'Cangatba Porac Pampanga', '2023-02-27', '54', 'N/A', 'N/A', '5000', 'BOF', 'Idk', '4000', 'Secret', '3000', 'Now', '5000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2000', 'Idk', 'Idk', 'My Account', '327589', '7584939357', '5748339956', 'Admin1', 'Admin2'),
(15, '980984', 'Anabelle C. Sarmiento', '2023-07-10', 'Cangatba Porac Pampanga', '2023-07-10', '65', 'N/A', 'N/A', '4000', 'GR Bank', 'Idk', '3000', 'Secret', '3000', 'Now', '4000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '1000', 'Idk', 'Idk', 'My Account', '326653', '138746583', '0456284936', 'Admin2', 'Admin1'),
(16, '567890', 'Jun B. Calo', '2023-08-15', 'Cangatba Porac Pampanga', '2023-08-15', '34', 'N/A', 'N/A', '8000', 'Metro Bank', 'Idk', '5000', 'Secret', '6000', 'Now', '3000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2000', 'Idk', 'Idk', 'My Account', '9504746', '574839084', '654890789', 'Admin1', 'admin2'),
(17, '567899', 'Rhea B. Turiuc', '2023-04-16', 'Cangatba Porac Pampanga', '2023-04-16', '62', 'N/A', 'N/A', '5000', 'China Bank', 'Idk', '3000', 'Secret', '3000', 'Now', '5000', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', '', 'Idk', 'Idk', 'My Account', '8676768', '57578484967', '46464738563', 'Admin1', 'Admin2'),
(18, '457532', 'Arman M. Santos', '2023-11-15', 'Cangatba Porac Pampanga', '2023-11-15', '66', 'N/A', 'N/A', '6000', 'GR Bank', 'Idk', '5000', 'secret', '3000', 'Now', '6000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2000', 'Idk', 'Idk', 'My Acoount', '6858876', '88599477835', '9588894058', 'Admin2', 'Admin1'),
(19, '463738', '', '2023-08-02', 'Cangatba Porac Pampanga', '2023-08-02', '74', 'N/A', 'N/A', '4000', 'BOF', 'Idk', '2000', 'Secret', '3000', 'Now', '4000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '1000', 'Idk', 'Idk', 'My Account', '4886874', '47773756639', '374747939596', 'Admin1', 'Admin2'),
(20, '46757639', 'Mylene H. Koma', '2023-09-17', 'Cangatba Porac Pampanga', '2023-09-17', '59', 'N/A', 'N/A', '9000', 'Metro Bank', 'Idk', '8000', 'Secret', '3000', 'Now', '9000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2000', 'Idk', 'Idk', 'My Account', '468902', '5478965489', '987345678', 'Admin2', 'Admin1'),
(21, '6478953', 'Paul M. Rosales', '2023-10-17', 'Cangatba Porac Pampanga', '2023-10-17', '58', 'N/A', 'N/A', '5000', 'GR Bank', 'Idk', '3000', 'Secret', '3000', 'Now', '5000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '1000', 'Idk', 'Idk', 'My Account', '4664882', '95877493369', '88577490372', 'Admin1', 'Admin2'),
(23, '789765', 'Monica A. Pilosa', '2023-02-14', 'Cangatba Porac Pampanga', '2023-02-14', '65', 'N/A', 'N/A', '7000', 'BOF', 'Idk', '4000', '', '3000', '', '7000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '3000', 'Idk', 'Idk', 'My Account', '786589', '8765678987', '23456456765', 'Admin2', 'Admin1'),
(24, '8659436', 'Noemi L. Magno', '2023-09-17', 'Cangatba Porac Pampanga', '2023-09-17', '55', 'N/A', 'N/A', '5000', 'Metro Bank', 'Idk', '4000', 'Secret', '3000', 'Now', '7000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '3000', 'Idk', 'Idk', 'My Account', '6789658', '6789976789', '6789678345', 'Admin2', 'Admin1'),
(26, '78976890', 'Vicente A. Mamban', '2023-07-19', 'Cangatba Porac Pampanga', '2023-07-19', '51', 'N/A', 'N/A', '8000', 'GR Bank', 'Idk', '5000', 'Secret', '3000', 'Now', '8000', 'Idk', 'Idk', 'idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '3000', 'Idk', 'Idk', 'My Account', '787689', '9023645678', '098934567', 'Admin1', 'Admin2'),
(27, '67898767', 'Jerry N. David', '2023-03-10', 'Cangatba Porac Pampanga', '2023-03-10', '44', 'N/A', 'N/A', '7000', 'BOF', 'Idk', '6000', 'Secret', '3000', 'Now', '7000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '3000', 'Idk', 'Idk', 'My Account', '89123', '234556798765', '456782349873', 'admin2', 'Admin1'),
(28, '64739967', 'Jomar A. Martin', '2023-09-17', 'Cangatba Porac Pampanga', '2023-09-17', '52', 'N/A', 'N/A', '6000', 'China Bank', 'Idk', '4000', 'Secret', '3000', 'Now', '6000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2500', 'Idk', 'Idk', 'My Account', '989584', '6473957493', '5656839265', 'Admin1', 'Admin2'),
(29, '867532', 'Jomari C. Pineda', '2023-03-21', 'Cangatba Porac Pampanga', '2023-03-21', '61', 'N/A', 'N/A', '5000', 'Metro Bank', 'Idk', '4000', 'Secret', '3000', 'Now', '5000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2000', 'Idk', 'Idk', 'My Account', '9357368', '87853562486', '784643456778', 'Admin1', 'Admin2'),
(30, '8368368', 'Marjun B. Coma', '2023-09-17', 'Cangatba Porac Pampanga', '2023-09-17', '37', 'N/A', 'N/A', '6000', 'BOF', 'Idk', '4000', 'Secret', '3000', 'Now', '6000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '3000', 'Idk', 'Idk', 'My Account', '588694', '88500048391', '995047769493', 'Admin1', 'Admin2'),
(32, '785900', 'Jaycee M. Kurma', '2023-05-03', 'Cangatba Porac Pampanga', '2023-05-03', '30', 'N/A', 'N/A', '8000', 'China Bank', 'N/A', '7000', 'Secret', '3000', 'Now', '6000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2000', 'Idk', 'Idk', 'My Account', '7885467', '357375287581', '934869388276', 'Admin2', 'Admin1'),
(33, '456784567886', 'Jerwayne', '2023-02-01', 'Cangatba', '2023-09-01', '5432', 'dffdsfsdf', 'dfdsfdffewwe', '45678987654', 'Porac', '789889h', '9708907890', 'gjhsvDJNSCBJCH', 'CASH', 'HJKH86768', '1', 'me', 'you', '4', 'ghj', 'you', '3', 'iris', 'jo', '22', 'ro', 'km', 'bv', 'jbj98777', '7809', '89', 'Secretary', 'Captain'),
(34, '456784567886', 'Jerwayne', '2023-02-01', 'Cangatba', '2023-12-07', '234567', '654dfg', '345678', '123456789', 'Porac', '56789', '78906789', 'hnvyfk8688h', 'Cash', 'hjoiugcvbn878fcv', '21', 'me', 'you', '5', 'fgbfd', 'you', '2', 'joan', 'davis', '11', 'ui', 'lj', 'jk', '808bjvj', '7809789', '98777', 'Secretary', 'Captain'),
(35, '456784567886', 'Jerwayne', '2023-02-01', 'Cangatba', '2023-09-01', '5432', 'dffdsfsdf', 'dfdsfdffewwe', '45678987654', 'Porac', '789889h', '9708907890', 'gjhsvDJNSCBJCH', 'CASH', 'HJKH86768', '1', 'me', 'you', '4', 'ghj', 'you', '3', 'iris', 'jo', '22', 'ro', 'km', 'bv', 'jbj98777', '7809', '89', 'Secretary', 'Captain'),
(36, '456784567886', 'Jerwayne', '2023-02-01', 'Cangatba', '2023-12-07', '234567', '654dfg', '345678', '123456789', 'Porac', '56789', '78906789', 'hnvyfk8688h', 'Cash', 'hjoiugcvbn878fcv', '21', 'me', 'you', '5', 'fgbfd', 'you', '2', 'joan', 'davis', '11', 'ui', 'lj', 'jk', '808bjvj', '7809789', '98777', 'Secretary', 'Captain'),
(37, '7895430', 'Dhainiel M. Colona', '2023-09-17', 'Cangatba', '2023-09-17', '27', 'N/A', 'N/A', '8000', 'GR Bank', 'Idk', '7000', 'Secret', '3000', 'Now', '8000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2000', 'Idk', 'Idk', 'My Account', '6849395', '769576594434', '543765876554', 'Admin1', 'Admin2'),
(40, '23748357', 'Harith A. Zapanta', '2023-09-17', 'Cangatba', '2023-09-17', '83', 'N/A', 'N/A', '5000', 'Metro Bank', 'Idk', '4000', 'Secret', '3000', 'Now', '5000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '2000', 'Idk', 'Idk', 'My Account', '1625464', '57873456345678', '5433567845678', 'Admin2', 'Amin1'),
(41, '989776', 'Trisha E. Reyes', '2023-09-27', 'Cangatba', '2023-09-27', '21', 'N/A', 'N/A', '5000', 'BOF', 'Idk', '3000', 'Secret', '3000', 'Now', '5000', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', 'Idk', '1000', 'Idk', 'Idk', 'My Account', '958438', '254675839464', '575767893933', 'Admin2', 'Admin1'),
(43, '959963', 'Vangie Y. Cura', '2023-06-29', 'Cangatba', '2023-06-29', '64', 'dfevbefb', 'brbetb', 'tgetg', 'etbtenbrtn', 'tbrthnr', 'ebrtb', 'ebrtb', 'rbrtbr', 'btrtbr', 'rbetbr', 'heyjeytjw', 'bryue5y', 'rbtrtbrtrbetgbr', 'ryhyhr', 'ervgbu56u', 'wgwrger', 'thertjy', 'rbueuyj', 'uytrgfd', 'etgu56', 'wrthb5u7', 'My Account', '76543', '98765489', '09876876543', 'Admin1', 'Admin2'),
(44, '8857739', 'Jonas T. Yabut', '2023-06-17', 'Cangatba', '2023-06-17', 'bhrbwr', 'nrntynnnt', 'tyu56u56ue', 'ue5yhu56wu', 'iuytrfhi', 'iuytr', 'oiuytrcvjhg', 'esrytuyi', 'uiyuiop', 'ertyuiolkb', 'ghjkfhbljh', 'rgerg', 'betbwrbw', ' sdbebwrtb', 'bsrtd', 'rtbrbrb ', 'asvnriej', 'trbgertbwt', 'rbrbrnw', 'hdsjhliaernuh', 'trhbwrtbert', 'ebhbrtb', 'ertyuiuyre', 'oiuytre', '5tuytr', 'iuytrgr', 'Admin2', 'Admin1'),
(46, '859937', 'Giyu A. tomioka', '2023-04-17', 'Cangatba', '2023-04-17', 'hfjfkkge', 'yjsrjyjsy', 'yrjeyj', 'rthrh', 'rthh', 'hjh7j57', 'h56h56h', 'jgfwrgkenrj', 'u6u6r', '6y65u', 'egth46u', '5j57j', '5h467h3', 'h56h5h', 'thtb', 'yjh457h4', '5yh57j5', 'tb5hhj5', '45j5', '5j57j', '5yh67j', 'eyh5yh', 'yj67j', 'j46j', 'ju6n', 'g4g4', 'Admin2', 'Admin1'),
(48, '588694', 'Linda S. Bisug', '2023-09-18', 'Cangatba', '2023-09-18', 'hh', 'thwh', '5h4h', 'eth4', '4heg45g', '4h4h5h', '45h46h', 'etgb4h56', '4hh4tb', 'h6h4h', 'dbgb', 'rtbrbrtbrt', 'vev4t', 'bbebrg', 'brbbrb', 'rge', 'btbteb', 'betbr', 'ebtb', 'ebrtbr', 'tbtb', 'tbg4tb4tb', 'b rg ', 'rgbr ', 'rbrtb', 'brtb', 'Admin1', 'Admin2'),
(49, '589956', 'Elena H. bunag', '2023-09-18', 'Cangatba', '2023-09-18', 'tyntn', 'uj7', 'nu7n7', 'byb6y', '6yb6yb', 'h6h', 'b6b6ub', '5g5yby', 'b6b6b', '6b6b', 'g', 'dcdc', 'fbvvbv', 'vhrvhr', 'vrvrvrn', 'fbrvb', 'rhvrv', 'ferfhrvjr', 'rvrvrhn', 'frvrv', 'vrvr', 'gtbt', 'fvrr', 'ecvr', 'edec', 'grv', 'Admin2', 'Admin1'),
(50, '577689', 'Regie K. Cruz', '2023-09-18', 'Cangatba', '2023-09-18', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'Admin1', 'Admin2'),
(51, '643673', 'Jemadel V. Yaya', '2023-09-18', 'Cangatba', '2023-09-18', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'Admin2', 'Admin1'),
(52, '464657', 'Nicole B. Sarmiento', '2023-09-18', 'Cangatba', '2023-09-18', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'Admin1', 'Admin2'),
(53, '688493', 'Andrea N. Torres', '2023-09-18', 'Cangatba', '2023-09-18', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'Admin2', 'Admin1'),
(54, '568884', 'Andy A. Hipolipo', '2023-09-18', 'Cangatba', '2023-09-18', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'Admin2', 'Admin1'),
(55, '996883', 'Sarah M. Chua', '2023-09-18', 'Cangatba', '2023-09-18', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'Admin2', 'Admin1'),
(56, '11611', 'Bryan V. Torres', '2023-09-18', 'Cangatba', '2023-09-18', 'g', 'g', 'g', 'g', '', '', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'Admin1', 'Admin2');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `username`, `action`, `timestamp`) VALUES
(1, 'capstone', 'Add Blotter', '2023-11-04 12:32:12'),
(2, 'capstone', 'Update Blotter', '2023-11-04 12:34:34'),
(3, 'capstone', 'Delete Blotter', '2023-11-04 12:34:55'),
(4, 'jerwayne', 'Add Blotter', '2023-11-04 12:37:03'),
(5, 'jerwayne', 'Update Blotter', '2023-11-04 12:37:32'),
(6, 'jerwayne', 'Delete Blotter', '2023-11-04 12:37:47'),
(9, 'capstone', 'Add Official', '2023-11-04 12:54:17'),
(10, 'capstone', 'Update Official', '2023-11-04 12:54:34'),
(11, 'capstone', 'Delete Official', '2023-11-04 12:54:46'),
(12, 'capstone', 'Add Resident', '2023-11-04 12:59:32'),
(13, 'capstone', 'Update Resident', '2023-11-04 12:59:54'),
(14, 'capstone', 'Delete Resident', '2023-11-04 13:00:01'),
(15, 'capstone', 'Update Resident', '2023-11-04 13:04:27'),
(16, 'capstone', 'Delete Resident', '2023-11-04 13:04:38'),
(17, 'capstone', 'Delete User', '2023-11-04 13:06:00');

-- --------------------------------------------------------

--
-- Table structure for table `officials`
--

CREATE TABLE `officials` (
  `official_id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `term_start` date DEFAULT NULL,
  `term_end` date DEFAULT NULL,
  `term_status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `officials`
--

INSERT INTO `officials` (`official_id`, `full_name`, `position`, `term_start`, `term_end`, `term_status`) VALUES
(12, 'Paul Vincent D. Lusung', 'Captain', '2020-10-22', '2023-08-30', 'Active'),
(13, 'Jebrine S. Pineda', 'Kagawad', '2020-10-22', '2023-10-20', 'Active'),
(14, 'Francis Tubangui', 'Kagawad', '2020-10-22', '2023-10-20', 'Active'),
(15, 'Amelia J. Arnisto', 'Kagawad', '2020-10-22', '2023-10-20', 'Active'),
(16, 'Adnacion D. Yuzon', 'Kagawad', '2020-10-22', '2023-10-20', 'Active'),
(20, 'Kelvin Tolentino', 'Kagawad', '2020-10-22', '2023-10-20', 'Active'),
(21, 'Jerwayne D. Pineda', 'Secretary', '2020-10-22', '2023-10-20', 'Active'),
(25, 'Kate Angel Mangiliman', 'Captain', '2023-09-23', '2023-09-13', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `ID` int(11) NOT NULL,
  `pdf_type` varchar(255) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `cstatus` varchar(255) DEFAULT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `approval_status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`ID`, `pdf_type`, `fullname`, `age`, `address`, `purpose`, `date`, `cstatus`, `business_name`, `location`, `approval_status`) VALUES
(1, 'clearance', 'Rheanel Mangaring', 26, '82 Saup', 'educational', '2023-09-16', 'Single', NULL, NULL, 'Disapproved'),
(2, 'indigency', 'Rheanel Mangaring', 26, '81 Saup', 'educational', '2023-09-16', 'Single', NULL, NULL, 'Disapproved'),
(3, 'residency', 'Rheanel Mangaring', 26, '81 Saup', 'education', '2023-09-16', 'Single', NULL, NULL, 'Disapproved'),
(4, 'business', 'Rheanel Mangaring', NULL, '81 Saup', NULL, '2023-09-16', NULL, 'Moon Coffee', 'Cangatba', 'Disapproved'),
(5, 'indigency', 'Nico B. Tanedo', 21, 'Cangatba Porac', 'Scholar', '2023-09-18', 'Single', NULL, NULL, 'Approved'),
(6, 'indigency', 'Cindy S. Seng', 18, 'Cangatba Porac', 'Scholar', '2023-07-25', 'Single', NULL, NULL, 'Approved'),
(7, 'residency', 'Alex M. Cruz', 20, 'Cangatba Porac', 'School', '2023-08-18', 'Single', NULL, NULL, 'Approved'),
(8, 'residency', 'Roselle H. Reyes', 22, 'Cangatba Porac', 'work', '2023-07-19', 'Single', NULL, NULL, 'Disapproved'),
(9, 'indigency', 'Jaycee L. Ramos', 22, 'Cangatba Porac', 'Scholar', '2023-09-07', 'Single', NULL, NULL, 'Approved'),
(10, 'residency', 'Asher G. Mercado', 21, 'Cangatba Porac', 'Work', '2023-06-21', 'Single', NULL, NULL, 'Disapproved'),
(11, 'indigency', 'Nathaniel M. Prado', 22, 'Cangatba Porac', 'Scholar', '2023-08-22', 'Single', NULL, NULL, 'Approved'),
(12, 'residency', 'Adrian B. Usi', 25, 'Cangatba Porac', 'Work', '2023-06-22', 'Married', NULL, NULL, 'Pending'),
(13, 'residency', 'Jerry B. Sanchez', 27, 'Cangatba Porac', 'Work', '2023-09-18', 'Married', NULL, NULL, 'Pending'),
(14, 'business', 'Cath', NULL, 'Porac', NULL, '2023-09-06', NULL, 'BTS', 'Cangatba', 'Pending'),
(15, 'business', 'DRM', NULL, 'Cangatba', NULL, '2023-10-04', NULL, 'BHH', 'Cangatba', 'Pending'),
(16, 'business', 'JITS', NULL, 'Cangatba', NULL, '2023-09-04', NULL, 'KJJH', 'Cangatba', 'Pending'),
(17, 'clearance', 'Jane', 15, 'Cangatba', 'Financial', '2023-09-29', 'Single', NULL, NULL, 'Pending'),
(18, 'indigency', 'Jade', 54, 'Cangatba', 'Hospital Bill', '2023-02-09', 'Married', NULL, NULL, 'Pending'),
(19, 'residency', 'Aina Mae B. Manalili', 20, 'Cangatba, Porac Pampanga', '', '2023-09-18', 'Single', NULL, NULL, 'Pending'),
(20, 'indigency', 'Robert John S. Quimbao', 44, 'Cangatba, Porac Pampanga', 'Hospital Bill', '2023-09-20', 'Married', NULL, NULL, 'Pending'),
(21, 'indigency', 'Monico L. Simpao', 22, 'Cangatba, Porac Pampanga', 'Scholarship', '2023-09-11', 'Single', NULL, NULL, 'Pending'),
(22, 'residency', 'Jamaica D. Pangan', 29, 'Cangatba, Porac Pampanga', 'Work', '2023-09-20', 'Married', NULL, NULL, 'Pending'),
(23, 'clearance', 'Petter V. Bacani', 47, 'Cangatba, Porac Pampanga', 'Work', '2023-09-18', 'Married', NULL, NULL, 'Pending'),
(24, 'residency', 'Jossie S. Victor', 33, 'Cangatba, Porac Pampanga', 'Work', '2023-09-19', 'Married', NULL, NULL, 'Pending'),
(25, 'residency', 'Gabriel M. Cruz', 20, 'Canagtba, Porac Pampanga', 'Requirment in School', '2023-09-07', 'Single', NULL, NULL, 'Pending'),
(26, 'indigency', 'Mary Grace E. Garcia', 22, 'Cangatba, Porac Pampanga', 'Scholarship', '2023-09-04', 'Single', NULL, NULL, 'Pending'),
(27, 'indigency', 'Clarence B. Castro', 21, 'Cangatba, Porac Pampanga', 'Scholarship', '2023-09-13', 'Single', NULL, NULL, 'Pending'),
(28, 'indigency', 'Jasmine S. De Leon', 38, 'Cangatba, Porac Pampanga', 'Hospital bill', '2023-09-07', 'Married', NULL, NULL, 'Pending'),
(29, 'clearance', 'Justine Dave L. Panizal', 25, 'Cangatba, Porac Pampanga', '', '2023-09-15', 'Married', NULL, NULL, 'Pending'),
(30, 'clearance', 'Andrea B. Bucud', 18, 'Cangatba, Porac Pampanga', 'Work', '2023-09-18', 'Single', NULL, NULL, 'Pending'),
(31, 'residency', 'John Carl V. Sotto', 19, 'Cangatba, Porac Pampanga', 'School', '2023-09-04', 'Single', NULL, NULL, 'Pending'),
(32, 'indigency', 'Ralph C. Yusi', 28, 'Cangatba, Porac Pampanga', 'Work', '2023-09-05', 'Married', NULL, NULL, 'Pending'),
(33, 'clearance', 'Aaron B. Serano', 20, 'Cangatba, Porac Pampanga', 'School', '2023-09-11', 'Single', NULL, NULL, 'Pending'),
(34, 'clearance', 'Aaron B. Serano', 20, 'Cangatba, Porac Pampanga', 'School', '2023-09-11', 'Single', NULL, NULL, 'Pending'),
(35, 'clearance', 'Aaron B. Serano', 20, 'Cangatba, Porac Pampanga', 'School', '2023-09-11', 'Single', NULL, NULL, 'Pending'),
(36, 'clearance', 'Aaron B. Serano', 20, 'Cangatba, Porac Pampanga', 'School', '2023-09-11', 'Single', NULL, NULL, 'Pending'),
(37, 'clearance', 'Aaron B. Serano', 20, 'Cangatba, Porac Pampanga', 'School', '2023-09-11', 'Single', NULL, NULL, 'Pending'),
(38, 'clearance', 'Aaron B. Serano', 20, 'Cangatba, Porac Pampanga', 'School', '2023-09-11', 'Single', NULL, NULL, 'Pending'),
(39, 'indigency', 'Princess Lynet S. Dimal', 35, 'Cangatba, Porac Pampanga', 'Hospital bill', '2023-09-16', 'Married', NULL, NULL, 'Pending'),
(40, 'indigency', 'Princess Lynet S. Dimal', 35, 'Cangatba, Porac Pampanga', 'Hospital bill', '2023-09-16', 'Married', NULL, NULL, 'Pending'),
(41, 'indigency', 'Princess Lynet S. Dimal', 35, 'Cangatba, Porac Pampanga', 'Hospital bill', '2023-09-16', 'Married', NULL, NULL, 'Pending'),
(42, 'residency', 'Hori B. Koma', 24, 'Cangatba Porac', 'Work', '0000-00-00', 'Single', NULL, NULL, 'Pending'),
(43, 'indigency', 'Yana N. Magnus', 20, 'Cangatba Porac', 'Scholar', '2023-09-20', 'Single', NULL, NULL, 'Pending'),
(44, 'indigency', 'Hannah K. Yumul', 20, 'Cangatba Porac', 'Scholar', '2023-08-20', 'Single', NULL, NULL, 'Pending'),
(45, 'residency', 'Giyu L. Ganzon', 25, 'Cangatba Porac', 'Work', '2023-07-20', 'Married', NULL, NULL, 'Pending'),
(46, 'indigency', 'Justine U. Miranda', 21, 'Cangatba Porac', 'Scholar', '2023-09-05', 'Single', NULL, NULL, 'Pending'),
(47, 'residency', 'Jerome M. Balagtas', 22, 'Cangatba Porac', 'Work', '2023-08-24', 'Single', NULL, NULL, 'Pending'),
(48, 'residency', 'Jonathan A. Abubo', 28, 'Cangatba Porac', 'Work', '2023-08-10', 'Married', NULL, NULL, 'Pending'),
(49, 'indigency', 'Kianne V. David', 21, 'Cangatba Porac', 'Scholar', '2023-09-05', 'Single', NULL, NULL, 'Pending'),
(50, 'indigency', 'Gian A. Torres', 21, 'Cangatba Porac', 'Scholar', '2023-06-14', 'Single', NULL, NULL, 'Pending'),
(51, 'indigency', 'Aerol M. Isip', 21, 'Cangatba Porac', 'Scholar', '2023-08-10', 'Single', NULL, NULL, 'Pending'),
(52, 'residency', 'Liam N. Serrano', 26, 'Cangatba Porac', 'Work', '2023-06-23', 'Married', NULL, NULL, 'Pending'),
(53, 'indigency', 'Tristan O. Tamayo', 20, 'Cangatba Porac', 'Scholar', '2023-08-02', 'Single', NULL, NULL, 'Pending'),
(54, 'indigency', 'Stephanie B. Salunga', 21, 'Cangatba Porac', 'Scholar', '2023-09-06', 'Single', NULL, NULL, 'Pending'),
(55, 'residency', 'Jomar A. Nicolas', 25, 'Cangatba Porac', 'Work', '2023-07-28', 'Single', NULL, NULL, 'Pending'),
(56, 'indigency', 'Ashley I. Ocampo', 21, 'Cangatba Porac', 'Scholar', '2023-09-05', 'Single', NULL, NULL, 'Pending'),
(57, 'residency', 'Arnold M. Santos', 24, 'Cangatba Porac', 'Work', '2023-07-18', 'Single', NULL, NULL, 'Pending'),
(58, 'residency', 'Jillian G. Romano', 23, 'Cangatba Porac', 'Work', '2023-07-11', 'Single', NULL, NULL, 'Pending'),
(59, 'indigency', 'Gelo A. Yaya', 20, 'Cangatba Porac', 'Scholar', '2023-09-13', 'Single', NULL, NULL, 'Pending'),
(60, 'business', 'rheanel', NULL, 'saup', NULL, '2023-09-22', NULL, 'printing', 'cangatba', 'Pending'),
(61, 'business', 'iyanel', NULL, '82 saup', NULL, '2023-09-22', NULL, 'salon', 'cangatba', 'Pending'),
(62, 'business', 'rheanel mangaring', NULL, '81 saup', NULL, '2023-09-23', NULL, 'bakery', 'cangatba', 'Pending'),
(63, 'business', 'iya', NULL, '85 saup', NULL, '2023-09-23', NULL, 'parlor', 'cangatba', 'Pending'),
(64, 'business', 'nelrhea', NULL, 'saup', NULL, '2023-09-23', NULL, 'coffee shop', 'cangatba', 'Pending'),
(65, 'indigency', 'nelrhea', 26, 'saup', 'financial assistance', '2023-09-23', 'Single', NULL, NULL, 'Pending'),
(66, 'residency', 'nelrhea', 26, 'saup', 'education', '2023-09-23', 'Single', NULL, NULL, 'Approved'),
(67, 'business', 'Ace', NULL, 'Cangatba', NULL, '2023-09-23', NULL, 'Ace', 'Cangatba', 'Pending'),
(68, 'business', 'nelrhea serrano', NULL, '85 Saup Project', NULL, '2023-09-24', NULL, 'Sari-Sari Store', 'Cangatba', 'Pending'),
(69, 'business', 'nelrhea', NULL, '85 saup', NULL, '2023-09-24', NULL, 'mini donut store', 'cangatba', 'Pending'),
(70, 'clearance', 'ace', 20, 'saup', 'financial assistance', '2023-09-24', 'Single', NULL, NULL, 'Pending'),
(71, 'residency', 'Aldrin Ace', 19, 'saup', 'education', '2023-09-24', 'Single', NULL, NULL, 'Pending'),
(72, 'business', 'Aldrin Ace', NULL, 'saup', NULL, '2023-09-24', NULL, 'motor parts', 'cangatba', 'Pending'),
(73, 'indigency', 'Monnet', 22, 'cangatba', 'SAMPLE', '2023-09-24', 'Single', NULL, NULL, 'Pending'),
(74, 'business', 'Vincent', NULL, 'Cangatba', NULL, '2023-09-24', NULL, 'vince', 'Cangatba', 'Pending'),
(75, 'indigency', 'Aldrin Ace', 23, 'cangatba', 'Financial Assistance', '2023-09-24', 'Single', NULL, NULL, 'Approved'),
(76, 'clearance', 'Rheanel S. Mangaring', 26, '81 Saup', 'Financial', '2023-09-30', 'Single', NULL, NULL, 'Pending'),
(77, 'residency', 'Rheanel S. Mangaring', 26, '81 Saup', 'Education', '2023-09-30', 'Single', NULL, NULL, 'Approved'),
(78, 'indigency', 'Rheanel S. Mangaring', 26, '81 Saup', 'personal', '2023-09-30', 'Single', NULL, NULL, 'Pending'),
(79, 'business', 'Rheanel S. Mangaring', NULL, '81 Saup', NULL, '2023-09-30', NULL, 'Midnight Cafe', 'Cangatba', 'Disapproved'),
(80, 'clearance', 'Monnet Bansil', 22, 'Saup', 'Education', '2023-10-21', 'Single', NULL, NULL, 'Pending'),
(81, 'clearance', 'Monnet', 22, 'Saup', 'Education', '2023-10-21', 'Single', NULL, NULL, 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `resident`
--

CREATE TABLE `resident` (
  `resident_id` int(11) NOT NULL,
  `barangay_id` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `name_ext` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `birth_place` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `house_num` int(11) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `barangay` varchar(255) DEFAULT NULL,
  `civil_status` varchar(255) DEFAULT NULL,
  `citizenship` varchar(255) DEFAULT NULL,
  `religion` varchar(255) DEFAULT NULL,
  `education` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `sakit` varchar(255) DEFAULT NULL,
  `kapansanan` varchar(255) DEFAULT NULL,
  `fam_income` varchar(255) DEFAULT NULL,
  `source_income` varchar(255) DEFAULT NULL,
  `fam_planning` varchar(255) DEFAULT NULL,
  `house_unit` varchar(255) DEFAULT NULL,
  `water_supply` varchar(255) DEFAULT NULL,
  `toilet_facilities` varchar(255) DEFAULT NULL,
  `garbage_disposal` varchar(255) DEFAULT NULL,
  `date_accomplished` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `resident`
--

INSERT INTO `resident` (`resident_id`, `barangay_id`, `last_name`, `first_name`, `middle_name`, `name_ext`, `age`, `birthday`, `birth_place`, `gender`, `house_num`, `street`, `barangay`, `civil_status`, `citizenship`, `religion`, `education`, `occupation`, `sakit`, `kapansanan`, `fam_income`, `source_income`, `fam_planning`, `house_unit`, `water_supply`, `toilet_facilities`, `garbage_disposal`, `date_accomplished`) VALUES
(13, '2023-77788-13', 'Kabiling', 'Andrea', 'Flores', '', '30', '1992-10-10', 'Porac Hospital', 'Female', 88, '', 'Cangatba', 'Married', 'Filipino', 'Born Again Christian', 'College', 'Sales Lady', '', 'No', '', 'Government', 'No', 'Single House', 'Jetmatic', 'Water Sealed Shared', 'Segregation', '2023-09-19'),
(14, '2023-54195-14', 'Pamintuan', 'Reylien', 'Santos', '', '21', '2001-11-22', 'Porac Pampanga', 'Female', 122, '', 'Cangatba', 'Single', 'Filipino', 'Catholic', 'College', '', '', 'No', '', '', 'No', 'Single House', 'Tap Inside House', 'Water Sealed Shared', 'Segregation', '2023-09-14'),
(15, '2023-42474-15', 'Ibanez', 'Roy', 'Lalic', '', '22', '2001-05-19', 'Porac Pampanga', 'Male', 156, '', 'Saup Cangatba', 'Single', 'Filipino', 'INC', 'College', '', '', 'No', '', '', 'No', 'Single House', 'Tap Inside House', 'Water Sealed Shared', 'Pickup by Truck', '2023-09-15'),
(16, '2023-24301-16', 'Pineda', 'Anthony', 'Lopez', 'jr', '37', '1985-01-21', 'Porac Pampanga', 'Male', 127, '', 'Cangatba', 'Married', 'Filipino', 'Catholic', 'High School', 'Laborer', '', '', 'Labor', 'Private', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Shared', 'Segregation', '2023-09-18'),
(17, '2023-87129-17', 'Rivera', 'Christian', 'Bigak', '', '33', '1989-09-24', 'Porac Pampanga', 'Male', 135, '', 'Cangatba', 'Married', 'Filipino', 'BornAgain Chirstian', 'High School', 'Helper', '', 'No', '', 'Government', 'No', 'Single House', 'Public Well', 'Water Sealed Shared', 'Segregation', '2023-09-05'),
(18, '2023-5451-18', 'Esteban', 'Mark Cavin', 'Saltik', '', '50', '1972-10-25', 'Porac Pampanga', 'Male', 157, '', 'Cangatba', 'Married', 'Filipino', 'Catholic', 'College', 'Own business', '', 'No', 'Carinderia', 'Private', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Shared', 'Segregation', '2023-09-01'),
(19, '2023-8171-19', 'Bucud', 'Camille', 'Datu', '', '21', '2001-08-22', 'Porac Pampanga', 'Female', 120, '', 'Cangatba', 'Single', 'Filipino', 'Catholic', 'High School', 'Sales Lady', '', 'No', '', 'Government', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-04'),
(20, '2023-9133-20', 'Bautista', 'Ryan', 'Victoria', '', '55', '1969-03-08', 'Porac Pampanga', 'Male', 11, '', 'Cangatba', 'Married', 'Filipino', 'Catholic', 'College', '', '', 'No', '', '', 'No', 'Single House', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-11'),
(21, '2023-98378-21', 'Tayag', 'Angeline', 'Buli', '', '22', '2000-10-17', 'Porac Pampanga', 'Female', 141, '', 'Cangatba', 'Single', 'Filipino', 'Catholic', 'High School', 'Sales Lady', '', 'No', '', 'Government', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Shared', 'Segregation', '2023-09-17'),
(22, '2023-89338-22', 'Beltran', 'Camille', 'Kiaa', '', '38', '1985-02-19', 'Porac Pampanga', 'Female', 110, '', 'Cangatba', 'Married', 'Filipino', 'Catholic', 'High School', 'OFW', '', 'No', '', 'Private', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-11'),
(23, '2023-29382-23', 'Fernandez', 'Lawrence', 'Piy', '', '68', '1968-05-27', 'Porac Pampanga', 'Male', 9, '', 'Cangatba', 'Married', 'Filipino', 'Catholic', 'College', 'Laborer', '', 'No', 'Radiator Shop', 'Private', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-10'),
(24, '2023-99766-24', 'Gutierez', 'Maria', 'Gio', '', '71', '1952-07-28', 'Porac Pampanga', 'Female', 2, '', 'Cangatba', 'Widow', 'Filipino', 'Catholic', 'College', '', '', 'No', 'Sari-sari store', 'Private', 'No', 'Single House', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-11'),
(25, '2023-82032-25', 'Santos', 'Paulo', 'Dio', '', '20', '2002-10-22', 'Porac Pampanga', 'Male', 150, '', 'Cangatba', 'Single', 'Filipino', 'INC', 'College', '', '', 'No', '', '', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-19'),
(26, '2023-10687-26', 'Manalili', 'John Rick ', 'Dnu', '', '65', '1958-01-31', 'Porac Pampanga', 'Male', 7, '', 'Cangatba', 'Married', 'Filipino', 'Catholic', 'College', 'Mechanic', '', 'No', '', 'Government', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-11'),
(27, '2023-17357-27', 'Espiritu', 'Zandy', 'Dko', '', '63', '1960-09-17', 'Porac Pampanga', 'Female', 138, '', 'Saup Cangatba', 'Widow', 'Filipino', 'INC', 'College', 'House Wife', '', 'No', '', 'Private', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-11'),
(28, '2023-72265-28', 'Yassi', 'Marites', 'Futy', '', '53', '1969-09-30', 'Porac Pampang', 'Female', 129, '', 'Cangatba', 'Married', 'Filipino', 'Catholic', 'High school', 'House wife', '', 'No', '', '', 'No', 'Single House', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-19'),
(29, '2023-87222-29', 'Banal', 'Lovely', 'Nio', '', '37', '1986-09-27', 'Porac Pampanga', 'Female', 134, '', 'Cangatba', 'Married', 'Filipino', 'Catholic', 'High school', 'Sales lady', '', 'No', '', 'Government', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-21'),
(30, '2023-86656-30', 'Nepomuceno', 'Justine', 'Bong', '', '37', '1986-08-23', 'Porac Pampanga', 'Male', 15, '', 'Cangatba', 'Married', 'Filipino', 'INC', 'High school', 'Body guard', '', 'No', '', 'Government', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-11'),
(31, '2023-88129-31', 'Morales', 'Patrick', 'Mica', '', '26', '1996-10-10', 'Porac Pampanga', 'Male', 199, '', 'Cangatba', 'Single', 'Filipino', 'Catholic', 'High school', 'Helper', '', 'No', '', 'Government', 'No', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-17'),
(32, '2023-61230-32', 'Manalili', 'James', 'Sia', '', '21', '2002-10-29', 'Porac Pampanga', 'Male', 131, '', 'Cangatba', 'Single', 'Filipino', 'Catholic', 'High school', '', '', 'No', '', '', 'No', 'Single House', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-19'),
(33, '2023-9892-33', 'Puale', 'Marina', 'Dio', '', '22', '2001-12-22', 'Porac Pampanga', 'Male', 172, '', 'Cangatba', 'Single', 'Filipino', 'Catholic', 'College', '', '', 'No', '', '', 'No', 'Single House', 'Tap Inside House', 'Water Sealed Exclusive', 'Segregation', '2023-09-18'),
(34, '2023-21381-34', 'hu', 'jhg', 'mbjhghu', '', '55', '2023-09-05', 'jhy', 'Female', 123, 'mhjichuc', 'cangatba', 'Married', 'Filipino', 'Catholic', 'College', 'OFW', '', '', '', '', '', 'Apartment', 'Public Well', 'Water Sealed Exclusive', 'Pickup by Truck', '2023-09-22'),
(35, '2023-45793-35', 'Royo', 'Mitch', 'Reyes', '', '22', '2023-09-11', 'Porac', 'Female', 223, 'Saup', 'Cangatba', 'Single', 'Filipino', 'Iglesia', 'Elementary', 'Nurse', '', '', '', 'Private', '', 'Duplex', 'Tap Inside House', 'Water Sealed Exclusive', 'Pickup by Truck', '2023-09-19'),
(36, '2023-56275-36', 'hgkjhk', 'm,bnvvcxvb', 'xcvbnm', '', '', '0000-00-00', '', 'Male', 0, 'fghjkl', 'cangatba', 'Married', 'fghjkl', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(37, '2023-29714-37', 'Prado', 'Nathan', 'Buan', '', '21', '2023-06-01', 'Lubao', 'Male', 432, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(38, '2023-79858-38', 'Hilerra', 'Kevin', 'Tamayo', '', '20', '2003-07-23', 'Rosario', 'Male', 334, '', 'Cangatba ', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(39, '2023-78705-39', 'Gilermo', 'Harin', 'Zapanta', '', '19', '2005-03-23', 'San fernando', 'Female', 221, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(40, '2023-94020-40', 'Torrato', 'Alex', 'Bangcal', '', '20', '2003-02-23', 'Florida', 'Female', 443, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(41, '2023-42554-41', 'Buan', 'Herald', 'Cruz', '', '20', '2004-04-23', 'Diosdado', 'Male', 343, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(42, '2023-58076-42', 'Suba', 'Kate', 'Rovan', '', '22', '2001-06-23', 'Rosario', 'Female', 544, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(43, '2023-15008-43', 'Nulud', 'Renz', 'Batac', '', '21', '2023-03-23', 'Lubao', 'Male', 122, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(44, '2023-72486-44', 'Magliman', 'Bryan', 'Luna', '', '21', '2002-09-10', 'San fernando', 'Female', 346, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(45, '2023-40413-45', 'Roman', 'Patricia', 'Zapanta', '', '20', '2003-07-20', 'Rosario', 'Female', 542, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(46, '2023-33358-46', 'Haton', 'Kyoske', 'Suba', '', '21', '2002-02-23', 'Makati', 'Male', 217, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(47, '2023-48569-47', 'Miranda', 'Rose', 'Bunag', '', '19', '2004-08-23', 'Diosdado', 'Female', 346, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(48, '2023-55613-48', 'Rasma', 'Dave', 'Huni', '', '23', '2000-05-23', 'Diosdado', 'Male', 411, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(49, '2023-31299-49', 'Briones', 'Kelly', 'Matos', '', '21', '2002-03-23', 'Rosario', 'Female', 644, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(50, '2023-94866-50', 'Salonga', 'John', 'Barnap', '', '21', '2002-11-23', 'Lubao', 'Male', 222, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(51, '2023-28333-51', 'Roque', 'Adrian', 'Benitez', '', '20', '2003-10-23', 'Diosdado', 'Male', 116, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(52, '2023-30643-52', 'Usi', 'Renan', 'Hanma', '', '24', '1999-06-23', 'Rosario', 'Male', 321, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(53, '2023-36358-53', 'Layug', 'Josh', 'Lait', '', '22', '2001-03-23', 'Lubao', 'Male', 444, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(54, '2023-88106-54', 'Ulep', 'Tinay', 'Usi', '', '21', '2002-02-23', 'Diosdado', 'Female', 143, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(55, '2023-45-55', 'Zapanta', 'Maricar', 'Reyes', '', '21', '2002-11-23', 'Rosario', 'Female', 553, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(56, '2023-42498-56', 'Nicdao', 'Merlyn', 'Yosen', '', '27', '1993-07-23', 'Rosario', 'Female', 369, '', 'Cangatba', 'Married', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(57, '2023-93746-57', 'Usol', 'Fairy', 'Fajardo', '', '20', '2003-06-23', 'Makati', 'Female', 667, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(58, '2023-18232-58', 'Pamintuan', 'Nigel', 'Paraque', '', '21', '2002-02-23', 'Lubao', 'Male', 642, '', 'Cangatba', 'Single', 'Filipino', 'RC', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `usertype` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `otp` varchar(6) NOT NULL,
  `is_verified` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `username`, `password`, `usertype`, `email`, `otp`, `is_verified`, `created_at`) VALUES
('Aldrin Ace', 'ace', 'ace', 'user', 'mangilimankateangel@gmail.com', '418733', 1, '2023-09-16 03:47:07'),
('Ashley', 'asleyqt', '12345678', 'user', 'jvsantos2719@gmail.com', '618670', 1, '2023-09-23 05:53:57'),
('Benedict', 'benedictqt', '12345678', 'user', 'jvsantos2719@gmail.com', '506633', 1, '2023-09-23 06:14:27'),
('Capstone_Group6', 'capstone', 'group6', 'admin', '', '', 1, '2023-09-15 18:48:49'),
('Carl', 'carlqt', '12345678', 'user', 'jvsantos2719@gmail.com', '547851', 1, '2023-09-23 05:56:54'),
('Celine', 'celineqt', '12345678', 'user', 'jvsantos2719@gmail.com', '904253', 1, '2023-09-23 06:48:41'),
('Cindy', 'cindyqt', '12345678', 'user', 'jvsantos2719@gmail.com', '560545', 1, '2023-09-23 05:44:46'),
('Criselda', 'criseldaqt', '12345678', 'user', 'jvsantos2719@gmail.com', '892282', 1, '2023-09-23 06:46:21'),
('Deserie', 'deserieqt', '12345678', 'user', 'jvsantos2719@gmail.com', '415267', 1, '2023-09-23 06:52:51'),
('Dexie', 'dexieqt', '12345678', 'user', 'jvsantos2719@gmail.com', '256444', 1, '2023-09-23 06:44:07'),
('Ernee', 'erneeqt', '12345678', 'user', 'jvsantos2719@gmail.com', '908965', 1, '2023-09-23 06:57:41'),
('Fairy', 'fairy', '12345678', 'user', 'jvsantos2719@gmail.com', '710829', 1, '2023-09-23 06:47:21'),
('Faye', 'fayeqt', '12345678', 'user', 'jvsantos2719@gmail.com', '195225', 1, '2023-09-23 06:18:38'),
('Isaiah', 'isaiahqt', '12345678', 'user', 'jvsantos2719@gmail.com', '943343', 1, '2023-09-23 06:09:22'),
('iyanel', 'iya', 'iya', 'user', 'mangaringrheanel@gmail.com', '368934', 1, '2023-09-22 01:44:13'),
('Jaycee', 'jayceeqt', '12345678', 'user', 'jvsantos2719@gmail.com', '846920', 1, '2023-09-23 05:47:21'),
('Jeremy', 'jeremyqt', '12345678', 'user', 'jvsantos2719@gmail.com', '927743', 1, '2023-09-23 06:12:38'),
('Jerwayne Pineda', 'jerwayne', 'jerwayne020778', 'admin', '', '', 1, '2023-09-15 18:48:49'),
('Jonas', 'jonasqt', '12345678', 'user', 'jvsantos2719@gmail.com', '258701', 1, '2023-09-23 06:06:33'),
('Joshua', 'joshuaqt', '12345678', 'user', 'jvsantos2719@gmail.com', '695911', 1, '2023-09-23 06:01:47'),
('Jovan', 'jovanqt', '12345678', 'user', 'jvsantos2719@gmail.com', '610423', 1, '2023-09-23 06:31:57'),
('Justine', 'justineqt', '12345678', 'user', 'jvsantos2719@gmail.com', '159324', 1, '2023-09-23 06:00:56'),
('Kaye', 'kayeqt', '12345678', 'user', 'jvsantos2719@gmail.com', '200405', 1, '2023-09-23 06:24:01'),
('Kevin', 'kevinqt', '12345678', 'user', 'jvsantos2719@gmail.com', '889561', 1, '2023-09-23 06:04:43'),
('Leon', 'leonqt', '12345678', 'user', 'jvsantos2719@gmail.com', '738385', 1, '2023-09-23 06:21:29'),
('Margie', 'margieqt', '12345678', 'user', 'jvsantos2719@gmail.com', '134923', 1, '2023-09-23 06:10:18'),
('Martha', 'marthaqt', '12345678', 'user', 'jvsantos2719@gmail.com', '610357', 1, '2023-09-23 06:47:58'),
('Matteo', 'matteoqt', '12345678', 'user', 'jvsantos2719@gmail.com', '134092', 1, '2023-09-23 06:17:56'),
('Maxine', 'maxineqt', '12345678', 'user', 'jvsantos2719@gmail.com', '351850', 1, '2023-09-23 07:01:32'),
('Mayang', 'mayangqt', '12345678', 'user', 'jvsantos2719@gmail.com', '576529', 1, '2023-09-23 06:34:42'),
('Meos', 'meosqt', '12345678', 'user', 'jvsantos2719@gmail.com', '320965', 1, '2023-09-23 06:50:38'),
('Mercy', 'mercyqt', '12345678', 'user', 'jvsantos2719@gmail.com', '149082', 1, '2023-09-23 06:56:52'),
('Mica', 'micaqt', '12345678', 'user', 'jvsantos2719@gmail.com', '945052', 1, '2023-09-23 06:25:40'),
('Monnet', 'monnet', 'bansil', 'user', 'monnetbansil391@gmail.com', '129227', 1, '2023-09-17 06:04:35'),
('munix', 'munix', 'munix', 'user', 'mangilimankateangel@gmail.com', '484869', 1, '2023-09-23 05:45:52'),
('Mylene', 'myleneqt', '12345678', 'user', 'jvsantos2719@gmail.com', '230638', 1, '2023-09-23 06:35:43'),
('Nathaniel', 'nathanielqt', '12345678', 'user', 'jvsantos2719@gmail.com', '105495', 1, '2023-09-23 06:55:45'),
('Nathan', 'nathanqt', '12345678', 'user', 'jvsantos2719@gmail.com', '870038', 1, '2023-09-23 06:11:50'),
('Rheanel S. Mangaring', 'nelnel', '123456', 'user', 'mangaringrheanel@gmail.com', '697157', 1, '2023-09-30 03:36:23'),
('Nicole', 'nicoleqt', '12345678', 'user', 'jvsantos2719@gmail.com', '671197', 1, '2023-09-23 06:02:27'),
('Nico', 'nicoqt', '12345678', 'user', 'jvsantos2719@gmail.com', '300867', 1, '2023-09-23 05:46:28'),
('Noel', 'noelqt', '12345678', 'user', 'jvsantos2719@gmail.com', '960077', 1, '2023-09-23 06:11:03'),
('Norma', 'normaqt', '12345678', 'user', 'jvsantos2719@gmail.com', '855038', 1, '2023-09-23 06:04:05'),
('Ramil', 'ramilqt', '12345678', 'user', 'jvsantos2719@gmail.com', '565115', 1, '2023-09-23 05:58:45'),
('Regie', 'regieqt', '12345678', 'user', 'jvsantos2719@gmail.com', '646953', 1, '2023-09-23 06:54:31'),
('Ryan', 'ryanqt', '12345678', 'user', 'jvsantos2719@gmail.com', '709957', 1, '2023-09-23 06:51:47'),
('Sandy', 'sandyqt', '12345678', 'user', 'jvsantos2719@gmail.com', '235373', 1, '2023-09-23 06:45:32'),
('Santino', 'santinoqt', '12345678', 'user', 'jvsantos2719@gmail.com', '932777', 1, '2023-09-23 06:43:21'),
('Sarah', 'sarahqt', '12345678', 'user', 'jvsantos2719@gmail.com', '533195', 1, '2023-09-23 05:51:26'),
('Mr. Joshua Tiongco', 'Sensei Josh', 'JoshSensei143', 'user', 'mangilimankateangel@gmail.com', '789639', 1, '2023-09-23 16:27:39'),
('Shery', 'sheryqt', '12345678', 'user', 'jvsantos2719@gmail.com', '352418', 1, '2023-09-23 06:44:48'),
('Mr. Jonilo Mababa', 'Sir Jonilo Mababa', 'MababaJonilo143', 'user', 'mangilimankateangel@gmail.com', '636862', 1, '2023-09-23 16:31:20'),
('Mr. Richmon Carabeo', 'Sir Richmon Carabeo', 'Pogiako143', 'user', 'mangilimankateangel@gmail.com', '323765', 1, '2023-09-23 16:29:08'),
('Tomas', 'tomasqt', '12345678', 'user', 'jvsantos2719@gmail.com', '316700', 1, '2023-09-23 05:54:47'),
('Tristan', 'tristanqt', '12345678', 'user', 'jvsantos2719@gmail.com', '296082', 1, '2023-09-23 05:59:54'),
('Vincent', 'vince', 'Seniorhigh', 'user', 'jvsantos2719@gmail.com', '602510', 1, '2023-09-17 05:59:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blotter`
--
ALTER TABLE `blotter`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `budget`
--
ALTER TABLE `budget`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `officials`
--
ALTER TABLE `officials`
  ADD PRIMARY KEY (`official_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `resident`
--
ALTER TABLE `resident`
  ADD PRIMARY KEY (`resident_id`,`barangay_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blotter`
--
ALTER TABLE `blotter`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `budget`
--
ALTER TABLE `budget`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `officials`
--
ALTER TABLE `officials`
  MODIFY `official_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `resident`
--
ALTER TABLE `resident`
  MODIFY `resident_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
