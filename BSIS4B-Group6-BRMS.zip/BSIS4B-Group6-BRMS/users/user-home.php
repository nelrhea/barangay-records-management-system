<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BRMS - Home</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../assets/css/user.css">
</head>
<body>

<?php
session_start(); // Start the session if not already started

// Assuming the user's name is stored in the 'username' session variable
$userName = $_SESSION['username'];
?>

    <!--navbar-->
    <header>
        <ul class="nav">
            <li class="nav-item">
                <h6 class="mr-5">BRMS</h6>
            </li>
            <div class="bgy_logo">
                <img src="../assets/images/logo.png" class="logo" alt="">
            </div>
            <li class="nav-item">
                <a class="nav-link text-light" href="user-home.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-light" href="certificates.php">Certificates</a>
            </li>
        </ul>
        <div class="right_area">
            <span>Welcome, <?php echo $userName; ?></span>
            <a href="../index.php" >Log Out</a>
        </div>
    </header>

    
    <div class="content">
        <center>
        <img src="../assets/images/logo.png" class="barangay">
        </center>

    </div>





    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  




</body>
</html>