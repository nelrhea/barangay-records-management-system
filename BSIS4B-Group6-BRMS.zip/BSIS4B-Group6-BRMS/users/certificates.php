<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BRMS - Certificate List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <link rel="stylesheet" href="../assets/css/user.css">
    <link rel="stylesheet" href="../assets/css/usercert.css">

</head>
<body>
    
    <?php
session_start(); // Start the session at the beginning of your PHP script

// Check if 'username' is set in the session
if (isset($_SESSION['username'])) {
    $loggedInUser = $_SESSION['username'];
} else {
    header('Location: certificates.php'); // Redirect to the login page if not logged in
    exit(); // Terminate script execution after redirect
}
?>

<!--navbar-->
<header>
        <ul class="nav">
            <li class="nav-item">
                <h6 class="mr-5">BRMS</h6>
            </li>
            <div class="bgy_logo">
                <img src="../assets/images/logo.png" class="logo" alt="">
            </div>
            <li class="nav-item">
                <a class="nav-link text-light" href="user-home.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-light" href="certificates.php">Certificates</a>
            </li>
        </ul>
         <div class="right_area">
            <span>Welcome, <?php echo $loggedInUser; ?></span>
            <a href="../index.php" >Log Out</a>
        </div>
    </header>


<div class="certificatepage">
    <div id="certificatesList" class="certificateForm" data-role="page">
          <h4>Certificate Request</h4>
          
        <div class="card">
            <div class="card-content">
                <h5>Select Form Request</h5>
                <button type="button" data-toggle="modal" data-target="#Certificatemodal" class="clearance ml-3">Certificate Form</button>
                <button type="button" data-toggle="modal" data-target="#Businessmodal" class="business ml-5">Business Form</button>
            </div>
        </div>

        <!--ALL CERTIFICATE PDF modal-->
        <div class="modal fade" id="Certificatemodal" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="background-color:navy;">
                        <h5 class="modal-title text-light" id="exampleModalLabel">Certificate Forms</h5>
                        <button type="button" class="close text-light" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <form id="certificateform" method="POST" action="certificates-function.php">
                        <div class="row">
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Name</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="name" name="name">
                            </div>
                            <div class="col-md-5 mb-3">
                                <label><strong>Age</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="age" name="age">
                            </div>
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Address</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="address" name="address">
                            </div>
                            <div class="col-md-5 mb-3">
                                <label><b>Civil Status:</b></label>
                                    <select id="cstatus" name="cstatus" class="form-control">
                                        <option selected="selected" disabled="disabled">Select Civil Status</option>
                                        <option value="Single">SINGLE</option>
                                        <option value="Married">MARRIED</option>
                                        <option value="Widow">WIDOW</option>                        
                                    </select>
                            </div>
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Purpose</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="purpose" name="purpose">
                            </div>
                            <div class="col-md-5 mb-3">
                                <label><strong>Certificate Request</strong></label>
                                <select class="form-control" name="pdftype">
                                    <option value="clearance">Clearance</option>
                                    <option value="indigency">Indigency</option>
                                    <option value="residency">Residency</option>
                                </select>
                            </div>
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Date</strong></label>
                                <input type="date" class="form-control" autocomplete="off" id="date" name="date">
                            </div>
                            <div class="col-md-5">
                                <input type="hidden" class="form-control" id="approval" name="approval" value="Pending">
                            </div>
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                            <button type="submit" name="save" class="btn btn-success py-0">Submit</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--BUSINESS PERMIT-->
        <div class="modal fade" id="Businessmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="background-color:navy;">
                        <h5 class="modal-title text-light" id="exampleModalLabel">Business Permit Form</h5>
                        <button type="button" class="close text-light" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <form id="businessform" method="POST" action="certificates-function.php">
                        <div class="row">
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Proprietor</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="name" name="name">
                            </div>
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Address</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="address" name="address">
                            </div>
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Business/Trade Name</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="bname" name="bname">
                            </div>
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Location</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="location" name="location">
                            </div>
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Date</strong></label>
                                <input type="date" class="form-control" autocomplete="off" id="date" name="date">
                            </div>
                            <div class="col-md-5">
                                <input type="hidden" class="form-control" id="pdftype" name="pdftype" value="business">
                            </div>
                            <div class="col-md-5">
                                <input type="hidden" class="form-control" id="approval" name="approval" value="Pending">
                            </div>
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                            <button id="submit" name="business_save" class="btn btn-success">Submit</button>
                            <button type="button" class="btn btn-danger py-0" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--DISPALY TABLE-->
        <table class="certificatetable" id="certificatetable" data-role="table" border="1" cellspacing="5">
            <thead class="table">
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Type of Certificate</th>
                    <th scope="col">Status</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php
                
                    if (isset($_SESSION['username'])) {
                            $loggedInUser = $_SESSION['username'];
                        } else {
                            header('Location: certificate.php');
                    }
                    
                    
                    $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");
                    
                    // Get the logged-in user's ID from your session or authentication system
                    $loggedInUser = mysqli_real_escape_string($conn, $loggedInUser);
                    
                    $query = "SELECT r.fullname, r.pdf_type, r.approval_status
                              FROM requests AS r
                              INNER JOIN users AS u ON r.fullname = u.name
                              WHERE u.username = '$loggedInUser'";
                    
                    $query_run = mysqli_query($conn, $query);
                    
                    if (mysqli_num_rows($query_run) > 0) {
                        foreach ($query_run as $row) {
                            ?>
                            <tr>
                                <td class="fullname"><?php echo $row['fullname']; ?></td>
                                <td><?php echo $row['pdf_type']; ?></td>
                                <td><?php echo $row['approval_status']; ?></td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo "<h5>No Record Found</h5>";
                    }
                    ?>

                
            </tbody>

        </table>
        
        



    </div>
</div>

    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

 

    </body>
</html>