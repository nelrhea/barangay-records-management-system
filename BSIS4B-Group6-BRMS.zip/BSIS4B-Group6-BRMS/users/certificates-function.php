<?php
session_start();
$conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

if (isset($_SESSION['username'])) {
    $loggedInUser = $_SESSION['username'];
} else {
    header('Location: certificates.php'); // Redirect to the login page if not logged in
    exit(); // Terminate script execution after redirect
}


if(isset($_POST['save']))
{
    // Retrieve form data
$name = $_POST['name'];
$age = $_POST['age'];
$address = $_POST['address'];
$cstatus = $_POST['cstatus'];
$purpose = $_POST['purpose'];
$pdftype = $_POST['pdftype'];
$date = $_POST['date'];
$approval = $_POST['approval'];


// Prepare and execute SQL query
$query = "INSERT INTO requests (fullname, age, address, cstatus, purpose, pdf_type, date, approval_status) VALUES ('$name', '$age', '$address', '$cstatus', '$purpose', '$pdftype', '$date', '$approval')";

$query_run = mysqli_query($conn, $query);


if ($query_run) {
    $_SESSION['status'] = "Successfully Saved!";
    header('Location: certificates.php');
} else {
    $_SESSION['status'] = "Not Saved: " . mysqli_error($conn); 
    header('Location: certificates.php');
}

} 


if(isset($_POST['business_save']))
{
    // Retrieve form data
$name = $_POST['name'];
$address = $_POST['address'];
$bname = $_POST['bname'];
$location = $_POST['location'];
$pdftype = $_POST['pdftype'];
$date = $_POST['date'];
$approval = $_POST['approval'];


// Prepare and execute SQL query
$query = "INSERT INTO requests (fullname, address, business_name, location, pdf_type, date, approval_status) VALUES ('$name', '$address', '$bname', '$location', '$pdftype', '$date', '$approval')";

$query_run = mysqli_query($conn, $query);


if ($query_run) {
    $_SESSION['status'] = "Successfully Saved!";
    header('Location: certificates.php');
} else {
    $_SESSION['status'] = "Not Saved: " . mysqli_error($conn); 
    header('Location: certificates.php');
}

} 




?>
