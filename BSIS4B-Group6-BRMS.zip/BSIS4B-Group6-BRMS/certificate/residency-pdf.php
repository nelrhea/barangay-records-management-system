<?php
require('../fpdf186/fpdf.php');

// Establish a database connection (example with MySQLi)
$mysqli = new mysqli("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

$barangay_id = urldecode($_GET['barangay_id']);
    // Fetch data from the database for the specified Rcd_id
    $query = "SELECT last_name, first_name, middle_name, name_ext, age, civil_status, house_num, street
              FROM resident 
              WHERE barangay_id = ?";
    
    $stmt = $mysqli->prepare($query);

    $barangay_id = $_GET['barangay_id'];

// Fetch data from the database for the specified barangay_id
$stmt->bind_param("s", $barangay_id);
$stmt->execute();
$stmt->bind_result($last_name, $first_name, $middle_name, $name_ext, $age, $civil_status, $house_num, $street);
$stmt->fetch();

// Close the statement
$stmt->close();

$userInput = array(
    'purpose' => urldecode($_GET['purpose']),
    'date' => urldecode($_GET['date'])
);

class PDF extends FPDF {
    function Header() {
        // Set background color
        $this->SetFillColor(70, 130, 180); // RGB color values

        // Draw a filled rectangle as the header background
        $this->Rect(0, 0, $this->GetPageWidth(), 45, 'F');

        // Set header text color
        $this->SetTextColor(255); // White color

        // Add header content
        $this->SetFont('Arial', 'B', 13);
        $this->MultiCell(0, 5, 'Republic of the Philippines' . "\nProvince of Pampanga" . "\nMunicipality of Porac", 0, 'C');

        $this->SetTextColor(255, 215, 0); // Gold color

        // Add header content
        $this->SetFont('Arial', 'B', 20);
        $this->MultiCell(0, 10, 'BARANGAY CANGATBA', 0, 'C');

        $this->SetTextColor(0); // Black color

        // Add header content
        $this->SetFont('Arial', 'B', 15);
        $this->MultiCell(0, 5, 'OFFICE OF THE PUNONG BARANGAY', 0, 'C');

        // Insert an image
        $this->Image('../assets/images/logo.png', 10, 0, 40); // Replace 'logo.png' with your image file's path
        $this->Image('../assets/images/porac-logo.png', 160, 5, 30);
    }

}


$pdf = new PDF('P', 'mm', 'A4');
$pdf->AddPage();

$pdf->Ln();
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFillColor(232, 244, 248);
$pdf->SetFont('Arial', 'BU', 12);
$pdf->MultiCell(70, 20, 'BARANGAY OFFICIALS', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->MultiCell(70, 15, 'HON. PAUL VINCENT D. LUSUNG', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'PUNONG BARANGAY', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 12);
$pdf->SetTextColor(0, 0, 255);
$pdf->MultiCell(70, 20, 'BARANGAY KAGAWAD', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'HON. ADORACION D. YUZON', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'CHAIRMAN, WOMEN AND FAMILY', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'HON. JESUS D. PALO', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'CHAIRMAN, PEACE AND ORDER', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'HON. SHIRLEY I. DE GUZMAN', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'CHAIRMAN, ENVIRONMENTAL PROTECTION', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'HON. AMELIA J. ARNISTO', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'CHAIRMAN, EDUCATION', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'HON. FRANCIS G. TUBANGUI', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'CHAIRMAN, PUBLIC WORKS', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'HON. KELVIN D. TOLENTINO', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'CHAIRMAN, SOCIAL HEALTH', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'HON. JEBRINE S. PINEDA', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'CHAIRMAN, BUDGET AND APPROPRIATION', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'HON. LEIDEE GLYZZA D. LUMBA', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'SK CHAIRWOMAN CHAIRMAN, YOUTH AND SPORTS DEV`T', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'JERWAYNE D. PINEDA', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'BARANGAY SECRETARY', 0, 'C', true);

$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(70, 10, 'MANOLO T. DAVID', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 5, 'BARANGAY TREASURER', 0, 'C', true);
$pdf->SetX($pdf->GetX() - 10);
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(255, 0, 0);
$pdf->MultiCell(70, 16, '', 0, 1, 'C', true);

$pdf->SetTextColor(0, 0, 0);
// Set font and content
// Set font and content
$pdf->SetY($pdf->GetY() - 220);
$pdf->SetFont('Arial', 'BU', 25);
$pdf->Cell(255, 0, 'BARANGAY RESIDENCY ', 0, 1, 'C');

$pdf->SetY($pdf->GetY() + 10);
$pdf->SetX($pdf->GetX() + 65);
$text1 = '              THIS IS TO CERTIFY, THAT, ' . $first_name . ' ' . $middle_name . ' ' . $last_name . ' ' . $name_ext . ' , ' . $age . ' years of age, '. $civil_status .'residing at  ' . $house_num . ' ' . $street . ', Cangatba, Porac, Pampanga. He/she is personally known to me to be a good moral character, peaceful and law-abiding citizen of this community.' . "\n";

$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 5, $text1, 0, 'J');


$pdf->SetY($pdf->GetY() + 5);
$pdf->SetX($pdf->GetX() + 65);
$text3 = '          This certification is issued upon the request of ' . $first_name . ' ' . $middle_name . ' ' . $last_name . ' ' . $name_ext . ' for whatever legal purpose it may serve.' . "\n";
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 5, $text3, 0, 'J');


$dateParts = explode('-', $userInput['date']);
$year = $dateParts[0];
$month = $dateParts[1];
$day = $dateParts[2];

$pdf->SetY($pdf->GetY() + 5);
$pdf->SetX($pdf->GetX() + 65);
$text8 = '          Given this ' . $day . ' day of ' . $month . ' ' . $year . ' at Barangay Cangatba, Porac, Pampanga.' ."\n";
$pdf->SetFont('Arial', 'B', 12);
$pdf->MultiCell(0, 5, $text8, 0, 'J');

$pdf->SetY($pdf->GetY() + 15);
$pdf->SetX($pdf->GetX() + 120);
$text9 = '____________________________' ."\n". 'HON. PAUL VINCENT D. LUSUNG' ."\n";
$pdf->SetFont('Arial', 'B', 12);
$pdf->MultiCell(0, 5, $text9, 0, 'C');
$pdf->SetX($pdf->GetX() + 120);
$text10 = 'Punong Barangay'."\n";
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(0, 5, $text10, 0, 'C');


// Output PDF
$pdf->Output();
?>
