<?php
    $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

    if (isset($_GET['barangay_id'])) {
        $barangay_id = $_GET['barangay_id'];

        $query = "SELECT * FROM resident WHERE barangay_id='$barangay_id' ";
        $query_run = mysqli_query($conn, $query);

        if (mysqli_num_rows($query_run) > 0) {
            foreach ($query_run as $row) {
                ?>
                <div class="row">
                    <div class="col-md-5 ml-5 mb-3">
                        <label for=""><strong>Name</strong></label>
                        <input type="text" value="<?= $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'] . ' ' . $row['name_ext']; ?>" class="form-control" name="fname" id="fname">
                    </div>
                    <div class="col-md-5 ml-5 mb-3">
                        <label for=""><strong>Age</strong></label>
                        <input type="text" value="<?= $row['age']; ?>" class="form-control" name="age" id="age">
                    </div>
                    <div class="col-md-5 ml-5 mb-3">
                        <label for=""><strong>Address</strong></label>
                        <input type="text" value="<?= $row['house_num'] . ' ' . $row['zone']; ?>" class="form-control" name="address" id="address">
                    </div>
                    
                    
                </div>
                <?php
            }
        } else {
            echo "No Record Found";
        }
        
    }



       if (isset($_POST['approve'])) {

            $requestID = $_POST['id'];
            $query = "UPDATE requests SET approval_status = 'Approved' WHERE ID = '$requestID'";
            $query_run = mysqli_query($conn, $query);

            if ($query_run) {
                $_SESSION['status'] = "Request Approved!";
            } else {
                $_SESSION['status'] = "Approval Failed: " . mysqli_error($conn); 
            }
        } elseif (isset($_POST['disapprove'])) {
            $requestID = $_POST['id'];
            $query = "UPDATE requests SET approval_status = 'Disapproved' WHERE ID = '$requestID'";
            $query_run = mysqli_query($conn, $query);

            if ($query_run) {
                $_SESSION['status'] = "Request Disapproved!";
            } else {
                $_SESSION['status'] = "Disapproval Failed: " . mysqli_error($conn); 
            }
            
        }

        header('Location: certificate-page.php');

    ?>
