<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BRMS - Certificate List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/certificate.css">
    
        <?php include '../includes/header.php'; ?>
        <?php include '../includes/sidebar.php'; ?>
</head>
<body>
    <?php
session_start();
?>

<div class="certificatepage">
    <div id="certificatesList" class="certificateForm" data-role="page">
          <h4>Certificate Request</h4>
          
        <div class="card">
            <div class="card-content">
                <h5>Select Form Request</h5>
                <button type="button" data-toggle="modal" data-target="#Certificatemodal" class="clearance ml-3">Certificate Form</button>
                <button type="button" data-toggle="modal" data-target="#Businessmodal" class="business ml-5">Business Form</button>
            </div>
        </div>

        <!--ALL CERTIFICATE PDF modal-->
        <div class="modal fade" id="Certificatemodal" tabindex="-1" role="dialog" aria-labelledby="fetchDataModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header" style="background-color:navy;">
                        <h5 class="modal-title text-light" id="fetchDataModalLabel">Barangay Certificate Form</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="searchForm" action="#" method="POST">
                            <div class="row">
                                <div class="col-md-5 ml-5">
                                    <input type="text" name="barangay_id" placeholder="Search ID.." value="<?php if(isset($_GET['barangay_id'])){echo $_GET['barangay_id'];} ?>" class="form-control">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <button type="submit" class="btn btn-primary">Search</button>
                                </div>
                            </div>

                                    <div class="row" id="IndigencysearchResults">
                                        <!-- Display search results here -->
                                    </div>
                            </div>
                                <div class="row">
                                    <div class="col-md-5 ml-5">
                                        <label for="Purpose"><strong>Purpose</strong></label>
                                        <input type="text" id="Purpose" class="form-control" name="purpose" id="purpose">
                                    </div>
                                    <div class="col-md-5 ml-5 mb-3">
                                        <label for="Date"><strong>Date</strong></label>
                                        <input type="date" id="Date" class="form-control" name="date" id="date">
                                    </div>
                                </div>
                                    <div class="modal-footer" style="background-color:navy;">
                                    <button id="generateClearancePDF" class="btn btn-success ml-4">Clearance PDF</button>
                                    <button id="generateIndigencyPDF" class="btn btn-success ml-4">Indigency PDF</button>
                                    <button id="generateResidencyPDF" class="btn btn-success ml-4">Residency PDF</button>
                                    <button type="button" class="btn btn-danger ml-4" data-dismiss="modal">Close</button>
                                    </div>
                            </div>
                        </form>
                        
            </div>
        </div>

        <!--BUSINESS PERMIT-->
<div class="modal fade" id="Businessmodal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color:navy;">
                <h5 class="modal-title text-light" id="exampleModalLabel">Business Permit Form</h5>
                <button type="button" class="close text-light" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form id="businessform" method="POST" action="business-pdf.php">
                <div class="row">
                    <div class="col-md-8 ml-5 mb-3">
                        <label><strong>Proprietor</strong></label>
                        <input type="text" class="form-control" autocomplete="off" id="name" name="name">
                    </div>
                    <div class="col-md-8 ml-5 mb-3">
                        <label><strong>Address</strong></label>
                        <input type="text" class="form-control" autocomplete="off" id="address" name="address">
                    </div>
                    <div class="col-md-8 ml-5 mb-3">
                        <label><strong>Business/Trade Name</strong></label>
                        <input type="text" class="form-control" autocomplete="off" id="bname" name="bname">
                    </div>
                    <div class="col-md-8 ml-5 mb-3">
                        <label><strong>Location</strong></label>
                        <input type="text" class="form-control" autocomplete="off" id="location" name="location">
                    </div>
                    <div class="col-md-8 ml-5 mb-3">
                        <label><strong>Date</strong></label>
                        <input type="date" class="form-control" autocomplete="off" id="date" name="date">
                    </div>
                </div>
                <div class="modal-footer" style="background-color:navy;">
                    <button id="generatePDF" class="btn btn-success ml-4">Business Permit PDF</button>
                    <button type="button" class="btn btn-danger py-0" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>



<!--BUSINESS PERMIT-->
<div class="modal fade" id="Businessmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="background-color:navy;">
                        <h5 class="modal-title text-light" id="exampleModalLabel">Business Permit Form</h5>
                        <button type="button" class="close text-light" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <form id="businessform" method="POST" action="certificates-function.php">
                        <div class="row">
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Proprietor</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="name" name="name">
                            </div>
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Address</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="address" name="address">
                            </div>
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Business/Trade Name</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="bname" name="bname">
                            </div>
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Location</strong></label>
                                <input type="text" class="form-control" autocomplete="off" id="location" name="location">
                            </div>
                            <div class="col-md-8 ml-5 mb-3">
                                <label><strong>Date</strong></label>
                                <input type="date" class="form-control" autocomplete="off" id="date" name="date">
                            </div>
                            <div class="col-md-5">
                                <input type="hidden" class="form-control" id="pdftype" name="pdftype" value="barangay">
                            </div>
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                            <button id="submit" name="business_save" class="btn btn-success">Submit</button>
                            <button type="button" class="btn btn-danger py-0" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--DISPALY TABLE-->
    <div class="table-container">
        <table class="certificatetable" id="certificatetable" data-role="table" border="1" cellspacing="5">
            <thead class="table">
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Certificate</th>
                    <th scope="col">Purpose</th>
                    <th scope="col">Status</th>
                    <th scope="col">Operation</th>
                </tr>
            </thead>
            <tbody>
            <?php
                $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");
                
                $query = "SELECT * FROM requests WHERE approval_status = 'Pending'";
                $query_run = mysqli_query($conn, $query);
                
                if (mysqli_num_rows($query_run) > 0) {
                    foreach ($query_run as $row) {
                        ?>
                        <tr>
                            <td class="fullname"><?php echo $row['fullname']; ?></td>
                            <td><?php echo $row['pdf_type']; ?></td>
                            <td><?php echo $row['purpose']; ?></td>
                            <td><?php echo $row['approval_status']; ?></td>
                            <td>
                                <form method="POST" action="certificate-function.php">
                                <button type="button" class="btn btn-info pdf_btn btn-sm fas fa-file-pdf" title="PDF File"
                                        data-fullname="<?php echo $row['fullname']; ?>"
                                        data-pdftype="<?php echo $row['pdf_type']; ?>"></button>
                                    <input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
                                    <button type="submit" name="approve" class="btn btn-success btn-sm fas fa-check-circle" title="Approve"></button>
                                    <button type="submit" name="disapprove" class="btn btn-danger btn-sm fas fa-times-circle" title="Disapprove"></button>
                                </form>
                            </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo "<h5>No Record Found</h5>";
                }
                ?>
                
                                
            </tbody>
                
        </table>
    </div>









    </div>
</div>

    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<!-- CERTIFICATE-->
<!-- JavaScript -->
<script>
    $(document).ready(function () {
        $('#searchForm').submit(function (event) {
            event.preventDefault(); // Prevent form submission
            
            var barangay_id = $('input[name="barangay_id"]').val();
            
            // Perform AJAX request to fetch search results
            $.ajax({
                type: 'POST',
                url: 'certificate-function.php', // Create this PHP file to fetch search results
                data: { barangay_id: barangay_id },
                success: function (data) {
                    $('#searchResults').html(data); // Display search results
                }
            });
        });

        // PDF generation for clearance
        $('#generateClearancePDF').click(function (event) {
            event.preventDefault();
            var barangay_id = $('input[name="barangay_id"]').val();
            var userEnteredData = {
                purpose: $('#Purpose').val(),
                date: $('#Date').val()
            };
            var pdfUrl = 'clearance-pdf.php?barangay_id=' + barangay_id;
            pdfUrl += '&purpose=' + encodeURIComponent(userEnteredData.purpose);
            pdfUrl += '&date=' + encodeURIComponent(userEnteredData.date);
            window.open(pdfUrl, '_blank');
        });

        // PDF generation for indigency
        $('#generateIndigencyPDF').click(function (event) {
            event.preventDefault();
            var barangay_id = $('input[name="barangay_id"]').val();
            var userEnteredData = {
                purpose: $('#Purpose').val(),
                date: $('#Date').val()
            };
            var pdfUrl = 'indigency-pdf.php?barangay_id=' + barangay_id;
            pdfUrl += '&purpose=' + encodeURIComponent(userEnteredData.purpose);
            pdfUrl += '&date=' + encodeURIComponent(userEnteredData.date);
            window.open(pdfUrl, '_blank');
        });

        // PDF generation for residency
        $('#generateResidencyPDF').click(function (event) {
            event.preventDefault();
            var barangay_id = $('input[name="barangay_id"]').val();
            var userEnteredData = {
                purpose: $('#Purpose').val(),
                date: $('#Date').val()
            };
            var pdfUrl = 'residency-pdf.php?barangay_id=' + barangay_id;
            pdfUrl += '&purpose=' + encodeURIComponent(userEnteredData.purpose);
            pdfUrl += '&date=' + encodeURIComponent(userEnteredData.date);
            window.open(pdfUrl, '_blank');
        });
    });
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const pdfButtons = document.querySelectorAll(".pdf_btn");

    pdfButtons.forEach(button => {
        button.addEventListener("click", function () {
            const fullname = this.getAttribute("data-fullname");
            const pdftype = this.getAttribute("data-pdftype");

            // Handle the different PDF generation logic based on pdftype
            if (pdftype === "clearance") {
                // Generate Clearance PDF
                window.location.href = `user-clearance-pdf.php?fullname=${fullname}&pdftype=${pdftype}`;
            } else if (pdftype === "indigency") {
                // Generate Indigency PDF
                window.location.href = `user-indigency-pdf.php?fullname=${fullname}&pdftype=${pdftype}`;
            } else if (pdftype === "residency") {
                // Generate Residency PDF
                window.location.href = `user-residency-pdf.php?fullname=${fullname}&pdftype=${pdftype}`;
            } else if (pdftype === "business") {
                // Generate Residency PDF
                window.location.href = `user-business-pdf.php?fullname=${fullname}&pdftype=${pdftype}`;
            }
        });
    });
});
</script>



 

    </body>
</html>