<?php
session_start();
$conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

if (isset($_POST['register'])) {
    // Retrieve user input from the form
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $usertype = mysqli_real_escape_string($conn, $_POST['usertype']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    // Generate a random OTP (e.g., a 6-digit code)
    $otp = mt_rand(100000, 999999);
    
    // Send OTP via email
    $to = $email; // User's email address
    $subject = "Your OTP for Verification";
    $message = "Hi! ". $name .", your OTP is ".$otp.".";
    $headers = "From: cangatbaporac@brms.site";
    
    if (mail($to, $subject, $message, $headers)) {
        // Email sent successfully
        // Now, insert the new user into the database
        $insertQuery = "INSERT INTO users (name, username, password, usertype, email, otp) VALUES ('$name','$username', '$password', '$usertype', '$email', '$otp')";
        
        if (mysqli_query($conn, $insertQuery)) {
            header("Location: verify.php?success");
            exit();
        } else {
            header("Location: index.php?error=database_error");
            exit();
        }
    } else {
        // Error sending email
        header("Location: index.php?error=email_error");
        exit();
    }
}

if (isset($_POST['verify'])) {
    $verotp = $_POST['otp'];

    // Retrieve the email associated with the OTP from the database
    $selectQuery = "SELECT email FROM users WHERE otp = ?";
    $stmt = mysqli_prepare($conn, $selectQuery);
    mysqli_stmt_bind_param($stmt, "s", $verotp);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $email);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if ($email) {
        // Email OTP matched with the database
        // Update the user's record in the database to mark them as verified
        $updateQuery = "UPDATE users SET is_verified = 1 WHERE email = ?";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, "s", $email);
        if (mysqli_stmt_execute($stmt)) {
            // Update was successful
            echo "Email OTP verified successfully. You are now verified!";
            
            // Redirect the user to the index.php page after a successful verification
            header("Location: index.php");
            exit(); // Ensure that the script stops executing after the redirect
        } else {
            // Handle the error
            echo "Error updating verification status: " . mysqli_error($conn);
        }
    } else {
        echo "Email OTP is wrong!";
        // Handle incorrect OTP input
    }
}



if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the user is verified before performing the login
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password' AND is_verified = 1";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $usertype = $row['usertype'];
        
        $_SESSION['username'] = $username;
        $_SESSION['usertype'] = $usertype;

        if ($usertype === 'admin') {
            header("Location: ./home/home.php"); // Redirect to admin dashboard
            exit();
        } else {
            header("Location: ./users/user-home.php"); // Redirect to user dashboard
            exit();
        }
    } else {
        // Invalid credentials or user is not verified
        header("Location: index.php?error=invalid");
        exit();
    }
}



$conn->close();
?>
