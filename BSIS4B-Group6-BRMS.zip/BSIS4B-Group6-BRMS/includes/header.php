    <!--header-->
    <input type="checkbox" id="check">
    <header>
        <label for="check">
                <i class="fas fa-bars" id="sidebar_btn"></i>
            </label>
        
        <div class="left_area">
            <h3>BRMS</h3>
        </div>
        <div class="bgy_logo">
            <img src="../assets/images/logo.png" class="logo" alt="">
        </div>
    </header>
    <div class="right_area">
            <span>Administrator</span>
    </div>
    <div class="right_logout">
    <a href="../index.php">
        <span class="nav-item text-light">Logout</span>
    </a>
    </div>
