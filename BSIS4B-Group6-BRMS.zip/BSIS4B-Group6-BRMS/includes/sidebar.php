<?php
session_start(); // Start the session if not already started

// Assuming the user's name is stored in the 'username' session variable
$userName = $_SESSION['username'];

?>
<!--Sidebar-->
<div class="sidebar">

          <div class="brgy_logo">
    <center>
        <?php
        // Define the path to the folder where images are stored.
        $imagePathFolder = '../assets/images/';

        // Check if the administrator is logged in. You can implement your own authentication logic here.
        $isAdminLoggedIn = true; // Replace with your authentication logic.

        if ($isAdminLoggedIn) {
            // Get the username of the logged-in administrator.
            $adminUsername = $userName; // Replace with the actual username.

            // Check which administrator is logged in based on their username.
            if ($adminUsername === 'capstone') {
                // Construct the full path to the first administrator's image.
                $fullImagePath = $imagePathFolder . 'group6.png'; // Change the file extension as needed.
            } elseif ($adminUsername === 'jerwayne') {
                // Construct the full path to the second administrator's image.
                $fullImagePath = $imagePathFolder . 'logo.png'; // Change the file extension as needed.
            } else {
                // Default case if neither admin1 nor admin2 is logged in.
                $fullImagePath = $imagePathFolder . 'default.jpg'; // Change to your default image path.
            }

            // Check if the image file exists.
            if (file_exists($fullImagePath)) {
                // Display the administrator's image.
                echo "<img src='$fullImagePath' alt='User Image' class='logo'>";
            } else {
                // If the image file is not found, display a default image.
                echo "<img src='../assets/images/user.png' alt='User Image' class='logo'>";
            }
        } else {
            // If the administrator is not logged in, display a default image.
            echo "<img src='../assets/images/user.png' alt='User Image' class='logo'>";
        }
        ?>
        <h5><?php echo $userName; ?></h5>
    </center>
</div>

            <a href="../dashboard/dashboard.php">
                <i class="fas fa-window-restore"></i>
                <span class="nav-item">Dashboard</span>
            </a>
            <a href="../budget/budget-page.php">
                <i class="fas fa-wallet"></i>
                <span class="nav-item">Budget</span>
            </a>
            <a href="../blotter/blotter-page.php">
                <i class="fas fa-file"></i>
                <span class="nav-item">Blotter Records</span>
            </a>
            <a href="../certificate/certificate-page.php">
                <i class="fas fa-certificate"></i>
                <span class="nav-item">Certificates</span>
            </a>
            <a href="../certificate-rec/cert-rec.php">
                <i class="fas fa-file-alt"></i>
                <span class="nav-item">Certificate Records</span>
            </a>
            <a href="../official/official-page.php">
                <i class="fas fa-users"></i>
                <span class="nav-item">Officials</span>
            </a>
            <a href="../resident/resident-page.php">
                <i class="fas fa-home"></i>
                <span class="nav-item">Residents</span>
            </a>
            <a href="../resident-id/resident_id-page.php">
                <i class="fas fa-id-card"></i>
                <span class="nav-item">Residents ID</span>
            </a>
            <a href="../user-list/user-list.php">
                <i class="fas fa-table-list"></i>
                <span class="nav-item">Users</span>
            </a>
            <a href="../history/history.php">
                <i class="fas fa-history"></i>
                <span class="nav-item">History</span>
            </a>

    </div>