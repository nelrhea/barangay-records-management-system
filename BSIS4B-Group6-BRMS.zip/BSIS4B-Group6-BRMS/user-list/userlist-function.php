<?php

session_start();
$conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

//delete
if (isset($_GET['userId'])) {
    
    $userName = $_SESSION['username'];

    $userid = $_GET['userId'];
    
    $delete_query = "DELETE FROM users WHERE username = '$userid'";
    $result = mysqli_query($conn, $delete_query);
    
    if ($result) {
        header("Location: user-list.php"); // Redirect back to your original page after deletion
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    
    $action = "Delete User"; 
    $timestamp = date("Y-m-d H:i:s");

    $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
    mysqli_query($conn, $logQuery);
}
mysqli_close($conn);
?>