<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BRMS - User List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/userlist.css">

        <?php include '../includes/header.php'; ?>
        <?php include '../includes/sidebar.php'; ?>

</head>
<body>
    <?php
session_start();
?>

        <div class="users">
            <div id="userList" class="userForm" data-role="page">
                <h4>User List</h4>
                <!--view official table-->
                <div class="table-container">
                    <table class="usertable table-bordered" id="usertable" data-role="table" border="1" cellspacing="5">
                        <thead class="table">
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Username</th>
                                <th scope="col">Email</th>
                                <th scope="col">Operation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");
                                $user_type_to_filter = 'user'; // Replace 'desired_user_type' with the actual user type you want to filter

                                $query = "SELECT * FROM users WHERE usertype = '$user_type_to_filter' ORDER BY name ASC";
                                $query_run = mysqli_query($conn, $query);
    
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    foreach($query_run as $row)
    
                                    {
                                        ?>
                                        <?php
                                        $userid = $row['username'];
                                        ?>
                                            <tr>
                                                <td><?php echo $row['name']; ?></td>
                                                <td><?php echo $row['username']; ?></td>
                                                <td><?php echo $row['email']; ?></td>
                                                
                                                <td>
                                                <a href="userlist-function.php?userId=<?php echo $userid; ?>" class=" text-light ml-2 delete_btn">Delete</a>                                        
                                                </td>                                            
                                            </tr>
    
                                        <?php
                                    }
                                }
                                else
                                {
                                    echo "<h5>No Record Found</h5>";
                                }
                                ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>




     <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>

    </body>
</html>