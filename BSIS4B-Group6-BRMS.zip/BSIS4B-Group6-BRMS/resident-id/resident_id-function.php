<?php 
session_start();
$conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

    if(isset($_POST['input'])){
        $input = $_POST['input'];
        
        $query = "SELECT * FROM resident WHERE barangay_id LIKE '{$input}%'";

        $return = mysqli_query($conn, $query);

        
    }


     if(isset($_POST['resident_save']))
    {
        $userName = $_SESSION['username'];
        
        // create official
        $lname = $_POST['lnameadd'];
        $fname = $_POST['fnameadd'];
        $mname = $_POST['mnameadd'];
        $nameE = $_POST['nameEadd'];
        $age = $_POST['ageadd'];
        $bday = $_POST['bdayadd'];
        $pbirth = $_POST['Pbirthadd'];
        $gender = $_POST['genderadd'];
        $cstatus = $_POST['cstatusadd'];
        $citizen = $_POST['citizenadd'];
        $hnum = $_POST['hnumadd'];
        $street = $_POST['streetadd'];
        $barangay = $_POST['barangayadd'];
        $religion = $_POST['religionadd'];
        $education = $_POST['educationadd'];
        $occupation = $_POST['occupationadd'];
        $sakit = $_POST['sakitadd'];
        $kapansanan = $_POST['kapansananadd'];
        $income = $_POST['incomeadd'];
        $sincome = $_POST['Sincomeadd'];
        $planning = $_POST['FPAadd'];
        $unit = $_POST['unitadd'];
        $water = $_POST['wateradd'];
        $toilet = $_POST['toiletadd'];
        $garbage = $_POST['garbageadd'];
        $user = $_POST['useradd'];
        $pass = $_POST['passadd'];
    
        $accomplished = $_POST['accomplishedadd'];
    
    
    
    
        $query = "INSERT INTO resident (last_name,first_name,middle_name,name_ext,age,birthday,birth_place,gender,civil_status,citizenship,house_num,street,barangay,religion,education,occupation,sakit,kapansanan,fam_income,source_income,fam_planning,house_unit,water_supply,toilet_facilities,garbage_disposal,username,password,date_accomplished) VALUES ('$lname','$fname','$mname','$nameE','$age','$bday','$pbirth','$gender','$cstatus','$citizen','$hnum','$street','$barangay','$religion','$education','$occupation','$sakit','$kapansanan','$income','$sincome','$planning','$unit','$water','$toilet','$garbage','$user','$pass','$accomplished')";
    
        $query_run = mysqli_query($conn, $query);
    
        if ($query_run) {
            $last_id = mysqli_insert_id($conn);
            if($last_id){
                $code = rand(1,99999);
                $barangay_id = "2023-".$code."-".$last_id;
                $query = "UPDATE resident SET barangay_id ='".$barangay_id."' WHERE resident_id ='".$last_id."'";
                $query_run = mysqli_query($conn, $query);
            }
            $_SESSION['status'] = "Successfully Saved!";
            header('Location: resident_id-page.php');
        } 
        else
        {
            $_SESSION['status'] = "Not Saved: " . mysqli_error($conn); 
            header('Location: resident_id-page.php');
        }
        
        $action = "Add Resident"; 
        $timestamp = date("Y-m-d H:i:s");
    
        $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
        mysqli_query($conn, $logQuery);
        
        }
    
    
        // read resident
        if(isset($_POST['checking_viewbtn']))
        {
            $r_id = $_POST['barangay_Id'];
            //echo $return = $o_id;
    
            $query = "SELECT * FROM resident WHERE barangay_id='$r_id'";
            $query_run = mysqli_query($conn, $query);
    
            if(mysqli_num_rows($query_run) > 0)
            {
                foreach($query_run as $row)
                {
                    echo $return = '
                        <table>
                            <tr>
                                <td>
                                    <h5 style="margin-left:15px;"><b>Barangay Id:</b> '.$row['barangay_id'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Full Name:</b> '.$row['last_name'].', '.$row['first_name'].' '.$row['middle_name'].' '.$row['name_ext'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Age:</b> '.$row['age'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Birthday:</b> '.$row['birthday'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Place of Birth:</b> '.$row['birth_place'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Gender:</b> '.$row['gender'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Civil Status:</b> '.$row['civil_status'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Citizenship:</b> '.$row['citizenship'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Address:</b> '.$row['house_num'].' '.$row['street'].' '.$row['barangay'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Religion:</b> '.$row['religion'].'</h5>
                                    <h5 style="margin-left:15px;"><b>Educational Attainment:</b> '.$row['education'].'</h5>
                                </td>
                                <td>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Occupation:</b> '.$row['occupation'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Uri ng Sakit:</b> '.$row['sakit'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>May Kapansanan:</b> '.$row['kapansanan'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Family Ave. Income:</b> '.$row['fam_income'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Source of Income:</b> '.$row['source_income'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Family Planning Acceptor:</b> '.$row['fam_planning'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Type of Housing Unit:</b> '.$row['house_unit'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Main Source of Water Supply:</b> '.$row['water_supply'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Type of Toilet Facilities Being Used:</b> '.$row['toilet_facilities'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Type of Garbage Disposal:</b> '.$row['garbage_disposal'].'</h5>
                                    <h5 style="margin-left:20px; margin-right:15px;"><b>Date Accomplished:</b> '.$row['date_accomplished'].'</h5>
                                </td>
                            </tr>
                        </table>
                    ';
    
    
                }
            }
            else
            {
                echo $return = "<h5>No Record Found</h5>";
            }
        }
    
    
        // update resident
        if(isset($_POST['checking_edit_btn']))
        {
            $bg_id = $_POST['barangay_Id'];
            //echo $return = $o_id;
            $result_array = [];
    
            $query = "SELECT * FROM resident WHERE barangay_id='$bg_id'";
            $query_run = mysqli_query($conn, $query);
    
            if(mysqli_num_rows($query_run) > 0)
            {
                foreach($query_run as $row)
                {
                    array_push($result_array, $row);
                    header('Content-type: application/json');
                    echo json_encode($result_array);
                }
            }
            else
            {
                echo $return = "<h5>No Record Found</h5>";
            }
        }
    
    
        if(isset($_POST['update_resident']))
        {
            $userName = $_SESSION['username'];
            
            $barang_id = $_POST['edit_id'];
            $lname = $_POST['lnameedit'];
            $fname = $_POST['fnameedit'];
            $mname = $_POST['mnameedit'];
            $nameE = $_POST['nameEedit'];
            $age = $_POST['ageedit'];
            $bday = $_POST['bdayedit'];
            $pbirth = $_POST['Pbirthedit'];
            $gender = $_POST['genderedit'];
            $cstatus = $_POST['cstatusedit'];
            $citizen = $_POST['citizenedit'];
            $hnum = $_POST['hnumedit'];
            $street = $_POST['streetedit'];
            $barangay = $_POST['barangayedit'];
            $religion = $_POST['religionedit'];
            $education = $_POST['educationedit'];
            $occupation = $_POST['occupationedit'];
            $sakit = $_POST['sakitedit'];
            $kapansanan = $_POST['kapansananedit'];
            $income = $_POST['incomeedit'];
            $sincome = $_POST['Sincomeedit'];
            $planning = $_POST['FPAedit'];
            $unit = $_POST['unitedit'];
            $water = $_POST['wateredit'];
            $toilet = $_POST['toiletedit'];
            $garbage = $_POST['garbageedit'];
            $accomplished = $_POST['accomplishededit'];
    
            $query = "UPDATE resident SET last_name='$lname', first_name='$fname', middle_name='$mname', name_ext='$nameE', age='$age', birthday='$bday', birth_place='$pbirth', gender='$gender', civil_status='$cstatus', citizenship='$citizen', house_num='$hnum', street='$street', barangay='$barangay', religion='$religion', education='$education', occupation='$occupation', sakit='$sakit', kapansanan='$kapansanan', fam_income='$income', source_income='$sincome', fam_planning='$planning', house_unit='$unit', water_supply='$water', toilet_facilities='$toilet', garbage_disposal='$garbage', date_accomplished='$accomplished'  WHERE barangay_id='$barang_id'";
            $query_run = mysqli_query($conn, $query);
    
            if ($query_run) {
                $_SESSION['status'] = "Successfully Updated!";
                header('Location: resident_id-page.php');
            } 
            else
            {
                $_SESSION['status'] = "Something went wrong!: " . mysqli_error($conn); 
                header('Location: resident_id-page.php');
            }
            
            $action = "Update Resident"; 
            $timestamp = date("Y-m-d H:i:s");
        
            $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
            mysqli_query($conn, $logQuery);
        }
    
    
        //delete resident
        if(isset($_POST['delete_resident']))
        {
            $userName = $_SESSION['username'];
            
            $bgId = $_POST['bgID'];
            $query = "DELETE FROM resident WHERE barangay_id='$bgId' ";
            $query_run = mysqli_query($conn, $query);
    
            if($query_run)
            {
                $_SESSION['status'] = "Successfully Deleted!";
                header('Location: resident_id-page.php');
            }
            else
            {
                $_SESSION['status'] = "Something went wrong!";
                header('Location: resident_id-page.php');
            }
            $action = "Delete Resident"; 
            $timestamp = date("Y-m-d H:i:s");
        
            $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
            mysqli_query($conn, $logQuery);
        }
    
    
    ?>