<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BRMS - Resident List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/resident_id.css">

        <?php include '../includes/header.php'; ?>
        <?php include '../includes/sidebar.php'; ?>
        

</head>
<body>
<?php
session_start();
?>

    <div class="residentpage">
        <div id="residentList" class="residentForm" data-role="page">
            <h4>Residents ID List</h4>
        
            <!--button to open modal-->
            <div class="search">
                <input type="text" id="searchInput" placeholder="Search Data Here...">
                <button id="clearButton">Clear</button>
            </div>

            <!--view official table-->
        <div class="table-container">
            <table class="residenttable" id="residenttable" data-role="table" border="1" cellspacing="5">
                <thead class="table">
                     <tr>
                        <th scope="col">Barangay Id</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Middle Name</th>
                        <th scope="col">Address</th>
                        <th scope="col">Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");
                        $query = "SELECT * FROM resident ORDER BY last_name ASC";
                        $query_run = mysqli_query($conn, $query);
                        if(mysqli_num_rows($query_run) > 0)
                        {
                            foreach($query_run as $row)
                            {
                                ?>
                                    <tr>
                                        <td class="barangayId"><?php echo $row['barangay_id']; ?></td>
                                        <td><?php echo $row['last_name']?></td>
                                        <td><?php echo $row['first_name']?></td>
                                        <td><?php echo $row['middle_name']?></td>
                                        <td><?php echo $row['house_num'] . ' ' . $row['street'] . ' ' . $row['barangay']; ?></td>

                                        <td>
                                            <a href="#" class="fas fa-eye text-succes2 view_btn" title="View"></a>
                                            <a href="#" class="fas fa-edit text-info edit_btn" title="Uoadate"></a>
                                            <a href="#" class="fas fa-trash-alt text-danger delete_btn" title="Delete"></a>
                                        </td>
                                    </tr>

                                <?php
                            }
                        }
                        else
                        {
                            echo "<h5>No Record Found</h5>";
                        }
                        ?>
                    
                </tbody>
            </table>
        </div>

            <!--view one official modal-->
            <div class="modal fade" id="ResidentViewmodal" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                    <div class="modal-header" style="background-color:navy;">
                        <h5 class="modal-title text-light" id="exampleModalLabel">View Resident Profile</h5>
                        <button type="button" class="close text-light" data-dismiss="modal">
                        <span>&times;</span>
                        </button>
                    </div>
                        <form id="addform" method="POST" enctype="" action="resident_id-function.php">
                            <div class="modal-body mb-5">
                                <div class="resident_viewing_data">
                                </div>
                            </div>
                            <div class="modal-footer mt-5" style="background-color:navy;">
                            <a href="resident_id-page.php" class=" text-light">Back to List</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!--update resident modal form-->
            <div class="modal fade" id="ResidenEdittmodal" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header" style="background-color:navy;">
                            <h5 class="modal-title text-light" id="exampleModalLabel"> Update Resident</h5>
                            <button type="button" class="close text-light" data-dismiss="modal">
                            <span>&times;</span>
                            </button>
                        </div>
                        <div id="editpage1">
                                <form id="editform" method="POST" enctype="" action="resident_id-function.php">
                                    <div class="row">
                                        <input type="hidden" id="edit_id" name="edit_id">
                                        <div class="col-md-3 mb-1">
                                            <label><b>Last Name:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_lname" name="lnameedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>First Name:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_fname" name="fnameedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Middle Name:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_mname" name="mnameedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Name Extension:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_nameE" name="nameEedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Age:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_age" name="ageedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Birthday:</b></label>
                                            <input type="date" class="form-control" autocomplete="off" id="edit_bday" name="bdayedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Place of Birth:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_Pbirth" name="Pbirthedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Gender:</b></label>
                                            <select id="edit_gender" name="genderedit" class="form-control">
                                                <option selected="selected" disabled="disabled">Select Gender</option>
                                                <option value="Female">FEMALE</option>
                                                <option value="Male">MALE</option>                      
                                            </select>                                        
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>House No.:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_hnum" name="hnumedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Zone/Street:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_street" name="streetedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Barangay:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_barangay" name="barangayedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Civil Status:</b></label>
                                            <select id="edit_cstatus" name="cstatusedit" class="form-control">
                                                <option selected="selected" disabled="disabled">Select Civil Status</option>
                                                <option value="Single">SINGLE</option>
                                                <option value="Married">MARRIED</option>
                                                <option value="Widow">WIDOW</option>                        
                                            </select>                                         
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Citizenship:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_citizen" name="citizenedit">
                                        </div>
                                    </div>
                                        <div class="modal-footer" style="background-color:navy;">
                                            <button type="button" class="btn btn-primary py-0" id="editnextPage">Next</button>
                                            <button type="button" class="btn btn-danger py-0" data-dismiss="modal">Close</button>
                                        </div>
                                    
                                </div>

                                <!-- Page 2 -->
                                <div id="editpage2" style="display: none;">
                                    <div class="row">
                                        <div class="col-md-3 mb-1">
                                            <label><b>Religion:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_religion" name="religionedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Educational Attainment:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_education" name="educationedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Occupation:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_occupation" name="occupationedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Uri ng Sakit:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_sakit" name="sakitedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>May Kapansanan:</b></label>
                                            <select id="edit_kapansanan" name="kapansananedit" class="form-control">
                                                <option selected="selected" disabled="disabled">Yes/No</option>
                                                <option value="Yes">YES</option>
                                                <option value="No">NO</option>
                                            </select>                                        
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Family Income:</b></label>
                                            <input type="text" class="form-control" autocomplete="off" id="edit_income" name="incomeedit">
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Source of Income:</b></label>
                                            <select id="edit_Sincome" name="Sincomeedit" class="form-control">
                                                <option selected="selected" disabled="disabled">Source of Income</option>
                                                <option value="Private">PRIVATE</option>
                                                <option value="Government">GOVERNMENT</option>
                                            </select>                                       
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Family Planning Acceptor:</b></label>
                                            <select id="edit_FPA" name="FPAedit" class="form-control">
                                                <option selected="selected" disabled="disabled">Yes/No</option>
                                                <option value="Yes">YES</option>
                                                <option value="No">NO</option>
                                            </select>                                       
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Housing Unit:</b></label>
                                            <select id="edit_unit" name="unitedit" class="form-control">
                                                <option selected="selected" disabled="disabled">Type of Housing Unit</option>
                                                <option value="Single House">SINGLE HOUSE</option>
                                                <option value="Duplex">DUPLEX</option>
                                                <option value="Apartment">APARTMENT</option>
                                                <option value="Improve Barong">IMPROVED BARONG</option>
                                                <option value="Others">OTHERS</option>
                                            </select>                                        
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Water Supply:</b></label>
                                            <select id="edit_water" name="wateredit" class="form-control">
                                                <option selected="selected" disabled="disabled">Source of Water Supply</option>
                                                <option value="Tap Inside House">TAP INSIDE HOUSE</option>
                                                <option value="Public Well">PUBLIC WELL</option>
                                                <option value="Private Deep Well">PRIVATE DEEP WELL</option>
                                                <option value="Jetmatic">JETMATIC</option>
                                            </select>                                       
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Toilet Facilities:</b></label>
                                            <select id="edit_toilet" name="toiletedit" class="form-control">
                                                <option selected="selected" disabled="disabled">Toilet Facilities Being Used</option>
                                                <option value="Water Sealed Exclusive">WATER SEALED EXCLUSIVE</option>
                                                <option value="Water Sealed Shared">WATER SEALED PRIVATE</option>
                                                <option value="Water Sealed Other Depository, excl">WATER SEALED OTHER DEPOSITORY, EXCL</option>
                                                <option value="Close Pit">CLOSED PIT</option>
                                                <option value="Open Pit">OPEN PIT</option>
                                            </select>                                       
                                        </div>
                                        <div class="col-md-3 mb-1">
                                            <label><b>Garbage Disposal:</b></label>
                                            <select id="edit_garbage" name="garbageedit" class="form-control">
                                                <option selected="selected" disabled="disabled">Type of Garbage Disposal</option>
                                                <option value="Pickup by Truck">PICKUP BY GARBAGE TRUCK</option>
                                                <option value="Segregation">SEGREGATION</option>
                                                <option value="Composting">COMPOSTING</option>
                                                <option value="Burying">BURYING</option>
                                                <option value="Burning">BURNING</option>
                                            </select>                                       
                                        </div>
                                        <div class="col-md-3 mb-1 mb-1">
                                            <label><b>Date Accomplished:</b></label>
                                            <input type="date" class="form-control" autocomplete="off" id="edit_accomplished" name="accomplishededit">
                                        </div>
                                    </div>
                                    <div class="modal-footer" style="background-color:navy;">
                                        <button type="button" class="btn btn-primary py-0" id="editprevPage">Previous</button>
                                        <button type="submit" name="update_resident" class="btn btn-success py-0">Update</button>
                                        <button type="button" class="btn btn-danger py-0" data-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!--delete resident modal-->
            <div class="modal fade" id="ResidentDelmodal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header" style="background-color:navy;">
                        <h5 class="modal-title text-light" id="exampleModalLabel">Delete Resident Record</h5>
                        <button type="button" class="close text-light" data-dismiss="modal">
                        <span>&times;</span>
                        </button>
                    </div>
                        <form id="addform" method="POST" enctype="" action="resident_id-function.php">
                            <div class="modal-body">
                                <input type="hidden" name="bgID" id="delete_id">
                                <span><label style="font-size:25px">Are you sure, you want to delete this record?</b></label></span>
                                
                            </div>
                            <div class="modal-footer" style="background-color:navy;">
                                <button type="submit" name="delete_resident" class="btn btn-danger py-0">Yes! Delete</button>
                                <button type="button" class="btn btn-secondary py-0" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            


        </div>
    </div>





    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
    <script>
    $(document).ready(function() {
        // Function to filter the table rows based on the search query
        function residenttable(query) {
            $('#residenttable tbody tr').each(function() {
                var barangay_id = $(this).find('td:nth-child(1)').text();
                var last_name = $(this).find('td:nth-child(2)').text();
                var first_name = $(this).find('td:nth-child(3)').text();
                var middle_name = $(this).find('td:nth-child(4)').text();

                // Show/hide the row based on the search query
                if (last_name.toLowerCase().includes(query.toLowerCase()) || first_name.toLowerCase().includes(query.toLowerCase()) || middle_name.toLowerCase().includes(query.toLowerCase()) || barangay_id.toLowerCase().includes(query.toLowerCase())) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }

        // Handle search input changes
        $('#searchInput').on('input', function() {
            var query = $(this).val();
            residenttable(query);
        });
        $('#clearButton').on('click', function() {
            // Clear the search input
            $('#searchInput').val('');

            // Reload the data by calling the filter function with an empty query
            residenttable('');

        });
    });
</script>
    
    <script>
        $(document).ready(function () {

            //read one resident record
            $('.view_btn').click(function (e) {
                e.preventDefault();

                var barangayId = $(this).closest('tr').find('.barangayId').text();
                //console.log(officialId);

                $.ajax({
                    type: "POST",
                    url: "resident_id-function.php",
                    data: {
                        'checking_viewbtn': true,
                        'barangay_Id': barangayId,
                    },
                    success: function(response) {
                        //console.log(response);
                        $('.resident_viewing_data').html(response);
                        $('#ResidentViewmodal').modal('show');

                    }
                });

            });


            //update official record
            $('.edit_btn').click(function (e) {
                
                var currentPage = 1;
                
                 $("#editnextPage").click(function () {
                if (currentPage === 1) {
                    $("#editpage1").hide();
                    $("#editpage2").show();
                    currentPage = 2;
                }
            });

            $("#editprevPage").click(function () {
                if (currentPage === 2) {
                    $("#editpage2").hide();
                    $("#editpage1").show();
                    currentPage = 1;
                }
            });

                
                e.preventDefault();

                var barangayId = $(this).closest('tr').find('.barangayId').text();
                //console.log(officialId);

                $.ajax({
                    type: "POST",
                    url: "resident_id-function.php",
                    data: {
                        'checking_edit_btn': true,
                        'barangay_Id': barangayId,
                    },
                    success: function(response) {
                        //console.log(response);
                        $.each(response, function(key, value){
                            //console.log(value['full_name']);

                            $('#edit_id').val(value['barangay_id']);
                            $('#edit_lname').val(value['last_name']);
                            $('#edit_fname').val(value['first_name']);
                            $('#edit_mname').val(value['middle_name']);
                            $('#edit_nameE').val(value['name_ext']);
                            $('#edit_age').val(value['age']);
                            $('#edit_bday').val(value['birthday']);
                            $('#edit_Pbirth').val(value['birth_place']);
                            $('#edit_gender').val(value['gender']);
                            $('#edit_cstatus').val(value['civil_status']);
                            $('#edit_citizen').val(value['citizenship']);
                            $('#edit_hnum').val(value['house_num']);
                            $('#edit_street').val(value['street']);
                            $('#edit_barangay').val(value['barangay']);
                            $('#edit_religion').val(value['religion']);
                            $('#edit_education').val(value['education']);
                            $('#edit_occupation').val(value['occupation']);
                            $('#edit_sakit').val(value['sakit']);
                            $('#edit_kapansanan').val(value['kapansanan']);
                            $('#edit_income').val(value['fam_income']);
                            $('#edit_Sincome').val(value['source_income']);
                            $('#edit_FPA').val(value['fam_planning']);
                            $('#edit_unit').val(value['house_unit']);
                            $('#edit_water').val(value['water_supply']);
                            $('#edit_toilet').val(value['toilet_facilities']);
                            $('#edit_garbage').val(value['garbage_disposal']);
                            $('#edit_accomplished').val(value['date_accomplished']);


                        });



                        $('#ResidenEdittmodal').modal('show');

                    }
                });

            });
        
        
            // delete resident record
            $('.delete_btn').click(function (e){
                e.preventDefault();

                var barangayId = $(this).closest('tr').find('.barangayId').text();
                //console.log(officialId);
                $('#delete_id').val(barangayId);
                $('#ResidentDelmodal').modal('show');

            });


            // search resident record
            $("#search").keyup(function(){
                var input = $(this).val();
                
                if(input != ""){
                    $.ajax({
                        url:"resident_id-function.php",
                        method:"POST",
                        data:{input:input},

                        success:function(data){
                            $("#searchresult").html(data);
                        }
                    });
                }else{
                    $("#searchresult").css("display","none");
                }
            });

        
        
        
        
        });
    </script>





    </body>
</html>