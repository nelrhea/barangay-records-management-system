<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BRMS - Blotter List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/blotter.css">


        <?php include '../includes/header.php'; ?>
        <?php include '../includes/sidebar.php'; ?>
</head>
<body>

<?php
session_start();
?>


<div class="blotterpage">
    <div id="blotterList" class="blotterForm" data-role="page">
          <h4>Blotter List</h4>
    
        <!--button to open modal-->
        <div class="container">
            <button type="button" data-toggle="modal" data-target="#Blottermodal">Add Blotter</button>
        </div>

        <!--save blotter form modal-->
        <div class="modal fade" id="Blottermodal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header" style="background-color:navy;">
                    <h5 class="modal-title text-light" id="exampleModalLabel">Manage Blotter Record</h5>
                    <button type="button" class="close text-light" data-dismiss="modal">
                    <span>&times;</span>
                    </button>
                </div>
                    <form id="addform" method="POST" enctype="" action="blotter-function.php">
                        <div class="modal-body">
                            <div class="column">
                                <label>Complainant:</label>
                                <input type="text" class="form-control" placeholder="Enter complainant name" autocomplete="off" name="complainantadd">
                            </div>
                            <div class="column">
                                <label>Age:</label>
                                <input type="number" class="form-control" placeholder="Enter age" autocomplete="off" name="Cageadd">
                            </div>
                            <div class="column">
                                <label>Address:</label>
                                <input type="text" class="form-control" placeholder="Enter address" autocomplete="off" name="Caddressadd">
                            </div>
                            <div class="column">
                                <label>Contact:</label>
                                <input type="number" class="form-control" placeholder="Enter contact number" autocomplete="off" name="Ccontactadd">
                            </div>
                            <div class="column">
                                <label>Complainee:</label>
                                <input type="text" class="form-control" placeholder="Enter complainee name" autocomplete="off" name="complaineeadd">
                            </div>
                            <div class="column">
                                <label>Age:</label>
                                <input type="number" class="form-control" placeholder="Enter age" autocomplete="off" name="Pageadd">
                            </div>
                            <div class="column">
                                <label>Address:</label>
                                <input type="text" class="form-control" placeholder="Enter address" autocomplete="off" name="Paddressadd">
                            </div>
                            <div class="column">
                                <label>Contact:</label>
                                <input type="number" class="form-control" placeholder="Enter contact number" autocomplete="off" name="Pcontactadd">
                            </div>
                            <div class="column">
                                <label>Complaint:</label>
                                <input type="text" class="form-control" placeholder="Enter complaint" autocomplete="off" name="complaintadd">
                            </div>
                            <div class="column">
                                <label>Action:</label>
                                <input type="text" class="form-control" placeholder="Enter action taken" autocomplete="off" name="actionadd">
                            </div>
                            <div class="column">
                                <label>Status:</label>
                                <input type="text" class="form-control" placeholder="Enter status" autocomplete="off" name="statusadd">
                            </div>
                            <div class="column">
                                <label>Location of Incidence:</label>
                                <input type="text" class="form-control" placeholder="Enter location of incidence" autocomplete="off" name="incidenceadd">
                            </div>
                            <div class="column mb-3">
                                <label>Date Recorded:</label>
                                <input type="date" class="form-control" placeholder="Enter date recorded" autocomplete="off" name="recordedadd">
                            </div>
                            
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                            <button type="submit" name="blotter_save" class="btn btn-success py-0">Submit</button>
                            <button type="button" class="btn btn-danger py-0" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--view blotter table-->
        <div class="table-container">
            <table class="blottertable" id="blottertable" data-role="table" border="1" cellspacing="5">
                <thead class="table">
                    <tr>
                        <th scope="col">Blotter Id</th>
                        <th scope="col">Date Recorder</th>
                        <th scope="col">Complainant</th>
                        <th scope="col">Person to Complaint</th>
                        <th scope="col">Complaint</th>
                        <th scope="col">Action Taken</th>
                        <th scope="col">Status</th>
                        <th scope="col">Location of Incidence</th>
                        <th scope="col">Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");
                        $query = "SELECT * FROM blotter";
                        $query_run = mysqli_query($conn, $query);

                        if(mysqli_num_rows($query_run) > 0)
                        {
                            foreach($query_run as $row)
                            {
                                ?>
                                    <tr>
                                        <td class="blotterId"><?php echo $row['blotter_id']; ?></td>
                                        <td><?php echo $row['recorded']; ?></td>
                                        <td><?php echo $row['complainant']; ?></td>
                                        <td><?php echo $row['complainee']; ?></td>
                                        <td><?php echo $row['complaint']; ?></td>
                                        <td><?php echo $row['action']; ?></td>
                                        <td><?php echo $row['status']; ?></td>
                                        <td><?php echo $row['incidence']; ?></td>
                                        <td>
                                            <a href="#" class="fas fa-eye text-success view_btn" title="View"></a>
                                            <a href="#" class="fas fa-edit text-info edit_btn" title="Update"></a>
                                            <a href="#" class="fas fa-trash-alt text-danger delete_btn" title="Delete"></a>
                                        </td>
                                    </tr>

                                <?php
                            }
                        }
                        else
                        {
                            echo "<h5>No Record Found</h5>";
                        }
                        ?>
                    
                </tbody>
            </table>
        </div>
        
        <!--view one blotter modal-->
         <div class="modal fade" id="BlotterViewmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header" style="background-color:navy;">
                    <h5 class="modal-title text-light" id="exampleModalLabel">View Blotter Record</h5>
                    <button type="button" class="close text-light" data-dismiss="modal">
                    <span>&times;</span>
                    </button>
                </div>
                    <form id="viewform" method="POST" enctype="multipart/form-data" action="blotter-function.php">
                        <div class="modal-body">
                            <div class="blotter_viewing_data">

                            </div>
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                        <a href="blotter-page.php" class=" text-light">Back to List</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        

        <!--edit blotter form modal-->
         <div class="modal fade" id="BlotterEditmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header" style="background-color:navy;">
                    <h5 class="modal-title text-light" id="exampleModalLabel">Manage Blotter Record</h5>
                    <button type="button" class="close text-light" data-dismiss="modal">
                    <span>&times;</span>
                    </button>
                </div>
                    <form id="addform" method="POST" enctype="" action="blotter-function.php">
                        <div class="modal-body">
                        <input type="hidden" id="edit_id" name="edit_id">
                            <div class="column">
                                <label>Complainant:</label>
                                <input type="text" class="form-control" placeholder="Enter complainant name" autocomplete="off" id="edit_complainant" name="complainantedit">
                            </div>
                            <div class="column">
                                <label>Age:</label>
                                <input type="number" class="form-control" placeholder="Enter age" autocomplete="off" id="edit_Cage" name="Cageedit">
                            </div>
                            <div class="column">
                                <label>Address:</label>
                                <input type="text" class="form-control" placeholder="Enter address" autocomplete="off" id="edit_Caddress" name="Caddressedit">
                            </div>
                            <div class="column">
                                <label>Contact:</label>
                                <input type="number" class="form-control" placeholder="Enter contact number" autocomplete="off" id="edit_Ccontact" name="Ccontactedit">
                            </div>
                            <div class="column">
                                <label>Complainee:</label>
                                <input type="text" class="form-control" placeholder="Enter complainee name" autocomplete="off" id="edit_complainee" name="complaineeedit">
                            </div>
                            <div class="column">
                                <label>Age:</label>
                                <input type="number" class="form-control" placeholder="Enter age" autocomplete="off" id="edit_Page" name="Pageedit">
                            </div>
                            <div class="column">
                                <label>Address:</label>
                                <input type="text" class="form-control" placeholder="Enter address" autocomplete="off" id="edit_Paddress" name="Paddressedit">
                            </div>
                            <div class="column">
                                <label>Contact:</label>
                                <input type="number" class="form-control" placeholder="Enter contact number" autocomplete="off" id="edit_Pcontact" name="Pcontactedit">
                            </div>
                            <div class="column">
                                <label>Complaint:</label>
                                <input type="text" class="form-control" placeholder="Enter complaint" autocomplete="off" id="edit_complaint" name="complaintedit">
                            </div>
                            <div class="column">
                                <label>Action:</label>
                                <input type="text" class="form-control" placeholder="Enter action taken" autocomplete="off" id="edit_action" name="actionedit">
                            </div>
                            <div class="column">
                                <label>Status:</label>
                                <input type="text" class="form-control" placeholder="Enter status" autocomplete="off" id="edit_status" name="statusedit">
                            </div>
                            <div class="column">
                                <label>Location of Incidence:</label>
                                <input type="text" class="form-control" placeholder="Enter location of incidence" autocomplete="off" id="edit_incidence" name="incidenceedit">
                            </div>
                            <div class="column mb-3">
                                <label>Date Recorded:</label>
                                <input type="date" class="form-control" placeholder="Enter date recorded" autocomplete="off" id="edit_recorded" name="recordededit">
                            </div>
                            
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                            <button type="submit" name="update_blotter" class="btn btn-success py-0">Submit</button>
                            <button type="button" class="btn btn-danger py-0" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <!--delete blotter modal-->
        <div class="modal fade" id="BlotterDelmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header" style="background-color:navy;">
                    <h5 class="modal-title text-light" id="exampleModalLabel">Delete Blotter Record</h5>
                    <button type="button" class="close text-light" data-dismiss="modal">
                    <span>&times;</span>
                    </button>
                </div>
                    <form id="addform" method="POST" enctype="multipart/form-data" action="blotter-function.php">
                        <div class="modal-body">
                            <input type="hidden" name="blotID" id="delete_id">
                            <span><label style="font-size:25px">Are you sure, you want to delete this record?</label></span>
                            
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                            <button type="submit" name="delete_blotter" class="btn btn-danger py-0">Yes! Delete</button>
                            <button type="button" class="btn btn-secondary py-0" data-dismiss="modal">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>



    </div>
</div>



<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  

    <script>
        $(document).ready(function () {

            //read one blotter record
            $('.view_btn').click(function (e) {
                e.preventDefault();

                var blotterId = $(this).closest('tr').find('.blotterId').text();
                //console.log(officialId);

                $.ajax({
                    type: "POST",
                    url: "blotter-function.php",
                    data: {
                        'checking_viewbtn': true,
                        'blotter_Id': blotterId,
                    },
                    success: function(response) {
                        //console.log(response);
                        $('.blotter_viewing_data').html(response);
                        $('#BlotterViewmodal').modal('show');

                    }
                });

            });


            //update blotter record
            $('.edit_btn').click(function (e) {
                e.preventDefault();

                var blotterId = $(this).closest('tr').find('.blotterId').text();
                //console.log(officialId);

                $.ajax({
                    type: "POST",
                    url: "blotter-function.php",
                    data: {
                        'checking_edit_btn': true,
                        'blotter_Id': blotterId,
                    },
                    success: function(response) {
                        //console.log(response);
                        $.each(response, function(key, value){
                            //console.log(value['full_name']);

                            $('#edit_id').val(value['blotter_id']);
                            $('#edit_complainant').val(value['complainant']);
                            $('#edit_Cage').val(value['Cage']);
                            $('#edit_Caddress').val(value['Caddress']);
                            $('#edit_Ccontact').val(value['Ccontact']);
                            $('#edit_complainee').val(value['complainee']);
                            $('#edit_Page').val(value['Page']);
                            $('#edit_Paddress').val(value['Paddress']);
                            $('#edit_Pcontact').val(value['Pcontact']);
                            $('#edit_complaint').val(value['complaint']);
                            $('#edit_action').val(value['action']);
                            $('#edit_status').val(value['status']);
                            $('#edit_incidence').val(value['incidence']);
                            $('#edit_recorded').val(value['recorded']);

                        });

                        $('#BlotterEditmodal').modal('show');

                    }
                });

            });

            // delete blotter record
            $('.delete_btn').click(function (e){
                e.preventDefault();

                var blotterId = $(this).closest('tr').find('.blotterId').text();
                //console.log(officialId);
                $('#delete_id').val(blotterId);
                $('#BlotterDelmodal').modal('show');

            });


        });
    </script>



    </body>
</html>