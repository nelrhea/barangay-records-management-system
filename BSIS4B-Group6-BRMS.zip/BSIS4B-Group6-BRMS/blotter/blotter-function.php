<?php

session_start();
$conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

if(isset($_POST['blotter_save']))
{
    $userName = $_SESSION['username'];
    
    $complainant = $_POST['complainantadd'];
    $Cage = $_POST['Cageadd'];
    $Caddress = $_POST['Caddressadd'];
    $Ccontact = $_POST['Ccontactadd'];
    $complainee = $_POST['complaineeadd'];
    $Page = $_POST['Pageadd'];
    $Paddress = $_POST['Paddressadd'];
    $Pcontact = $_POST['Pcontactadd'];
    $complaint = $_POST['complaintadd'];
    $action = $_POST['actionadd'];
    $status = $_POST['statusadd'];
    $incidence = $_POST['incidenceadd'];
    $recorded = $_POST['recordedadd'];


    $query = "INSERT INTO blotter (complainant,Cage,Caddress,Ccontact,complainee,Page,Paddress,Pcontact,complaint,action,status,incidence,recorded) VALUES ('$complainant','$Cage','$Caddress','$Ccontact','$complainee','$Page','$Paddress','$Pcontact','$complaint','$action','$status','$incidence','$recorded')";

    $query_run = mysqli_query($conn, $query);


    if ($query_run) {
        // Get the auto-incremented ID of the inserted record
        $autoIncrementedID = mysqli_insert_id($conn);

        // Construct the blotter_id using the current date and auto-incremented ID
        $currentYear = date("Y");
        $currentDate = date("md");
        $blotterID = $currentYear . $currentDate . $autoIncrementedID;

        // Update the record with the generated blotter_id
        $updateQuery = "UPDATE blotter SET blotter_id = '$blotterID' WHERE report_id = $autoIncrementedID";
        mysqli_query($conn, $updateQuery);
    
        $_SESSION['status'] = "Successfully Updated!";
        header('Location: blotter-page.php');
    } 
    else
    {
        $_SESSION['status'] = "Something went wrong!: " . mysqli_error($conn); 
        header('Location: blotter-page.php');
    }
    
    $action = "Add Blotter"; 
    $timestamp = date("Y-m-d H:i:s");

    $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
    mysqli_query($conn, $logQuery);
}

// read blotter
if(isset($_POST['checking_viewbtn']))
{
    $b_id = $_POST['blotter_Id'];
    //echo $return = $o_id;

    $query = "SELECT * FROM blotter WHERE blotter_id='$b_id'";
    $query_run = mysqli_query($conn, $query);

    if(mysqli_num_rows($query_run) > 0)
    {
        foreach($query_run as $row)
        {
            echo $return = '
                <h5> Blotter Id : '.$row['blotter_id'].'</h5>
                <h5> Date Recorded : '.$row['recorded'].'</h5>
                <h5> Complainant : '.$row['complainant'].'</h5>
                <h5> Person to Complain : '.$row['complainee'].'</h5>
                <h5> Action Taken : '.$row['action'].'</h5>
                <h5> Status : '.$row['status'].'</h5>
                <h5> Location of Incidence : '.$row['incidence'].'</h5>
            ';
        }
    }
    else
    {
        echo $return = "<h5>No Record Found</h5>";
    }
}


// update blotter
if(isset($_POST['checking_edit_btn']))
{
    $b_id = $_POST['blotter_Id'];
    //echo $return = $o_id;
    $result_array = [];

    $query = "SELECT * FROM blotter WHERE blotter_id='$b_id'";
    $query_run = mysqli_query($conn, $query);

    if(mysqli_num_rows($query_run) > 0)
    {
        foreach($query_run as $row)
        {
            array_push($result_array, $row);
            header('Content-type: application/json');
            echo json_encode($result_array);
        }
    }
    else
    {
        echo $return = "<h5>No Record Found</h5>";
    }
}


if(isset($_POST['update_blotter']))
{
    $userName = $_SESSION['username'];
    
    $blotter_id = $_POST['edit_id'];
    $complainant = $_POST['complainantedit'];
    $Cage = $_POST['Cageedit'];
    $Caddress = $_POST['Caddressedit'];
    $Ccontact = $_POST['Ccontactedit'];
    $complainee = $_POST['complaineeedit'];
    $Page = $_POST['Pageedit'];
    $Paddress = $_POST['Paddressedit'];
    $Pcontact = $_POST['Pcontactedit'];
    $complaint = $_POST['complaintedit'];
    $action = $_POST['actionedit'];
    $status = $_POST['statusedit'];
    $incidence = $_POST['incidenceedit'];
    $recorded = $_POST['recordededit'];

    $query = "UPDATE blotter SET blotter_id='$blotter_id', complainant='$complainant', Cage='$Cage', Caddress='$Caddress', Ccontact='$Ccontact', complainee='$complainee', Page='$Page', Paddress='$Paddress', Pcontact='$Pcontact', complaint='$complaint', action='$action', status='$status', incidence='$incidence', recorded='$recorded' WHERE blotter_id='$blotter_id'";
    $query_run = mysqli_query($conn, $query);

    if ($query_run) {
        $_SESSION['status'] = "Successfully Updated!";
        header('Location: blotter-page.php');
    } 
    else
    {
        $_SESSION['status'] = "Something went wrong!: " . mysqli_error($conn); 
        header('Location: blotter-page.php');
    }
    
     $action = "Update Blotter"; 
    $timestamp = date("Y-m-d H:i:s");

    $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
    mysqli_query($conn, $logQuery);
}


//delete blotter
if(isset($_POST['delete_blotter']))
{
    $userName = $_SESSION['username'];
    
    $blotId = $_POST['blotID'];
    $query = "DELETE FROM blotter WHERE blotter_id='$blotId' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Successfully Deleted!";
        header('Location: blotter-page.php');
    }
    else
    {
        $_SESSION['status'] = "Something went wrong!";
        header('Location: blotter-page.php');
    }
    
     $action = "Delete Blotter"; 
    $timestamp = date("Y-m-d H:i:s");

    $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
    mysqli_query($conn, $logQuery);
}


?>