<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BRMS - Official List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/officialstyle.css">
    <link rel="stylesheet" href="../assets/css/image.css">

        <?php include '../includes/header.php'; ?>
        <?php include '../includes/sidebar.php'; ?>
</head>
<body>
    
    <?php
session_start();
?>

<div class="officialpage">
    <div id="officialsList" class="officialForm" data-role="page">
          <h4>Official List</h4>
    
        <!--button to open modal-->
        <div class="container">
            <button type="button" data-toggle="modal" data-target="#Officialmodal">Add Official</button>
        </div>

        <!--view one official modal-->
        <div class="modal fade" id="OfficialViewmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header" style="background-color:navy;">
                    <h5 class="modal-title text-light" id="exampleModalLabel">View Official</h5>
                    <button type="button" class="close text-light" data-dismiss="modal">
                    <span>&times;</span>
                    </button>
                </div>
                    <form id="addform" method="POST" enctype="" action="official-function.php">
                        <div class="modal-body">
                            <div class="official_viewing_data">

                            </div>
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                        <a href="official-page.php" class=" text-light">Back to List</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--save official form modal-->
        <div class="modal fade" id="Officialmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header" style="background-color:navy;">
                    <h5 class="modal-title text-light" id="exampleModalLabel">Create Official Record</h5>
                    <button type="button" class="close text-light" data-dismiss="modal">
                    <span>&times;</span>
                    </button>
                </div>
                    <form id="addform" method="POST" enctype="" action="official-function.php">
                        <div class="row">
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Full Name</strong></label>
                                <input type="text" class="form-control" placeholder="Enter full name" autocomplete="off" required="required" id="fnameadd" name="fnameadd">
                            </div>
                            <div class="col-md-5 mb-3">
                                <label><strong>Select Position</strong></label>
                                <select id="positionadd" name="positionadd" class="form-control">
                                    <option selected="selected" disabled="disabled">Select Position</option>
                                    <option value="Captain">CAPTAIN</option>
                                    <option value="Kagawad">KAGAWAD</option>  
                                    <option value="Secretary">SECRETARY</option>
                                    <option value="Treasurer">TREASURER</option>
                                    <option value="Book Keeper">BOOK KEEPER</option>
                                    <option value="SK Chairman">SK CHAIRMAN</option>                     
                                </select>
                            </div>
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Term Start</strong></label>
                                <input type="date" class="form-control" placeholder="enter term start" autocomplete="off" required="required" id="startadd" name="startadd">
                            </div>
                            <div class="col-md-5 mb-3">
                                <label><strong>Term End</strong></label>
                                <input type="date" class="form-control" placeholder="enter term end" autocomplete="off" required="required" id="endadd" name="endadd">
                            </div>
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Status</strong></label>
                                <select id="statusadd" name="statusadd" class="form-control">
                                    <option selected="selected" disabled="disabled">Select Status</option>
                                    <option value="Active">ACTIVE</option>
                                    <option value="Inactive">INACTIVE</option>                    
                                </select>
                            </div>
                            
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                            <button type="submit" name="save_official" class="btn btn-success py-0">Submit</button>
                            <button type="button" class="btn btn-danger py-0" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--edit official form modal-->
        <div class="modal fade" id="OfficialEditmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header" style="background-color:navy;">
                    <h5 class="modal-title text-light" id="exampleModalLabel">Update Official Record</h5>
                    <button type="button" class="close text-light" data-dismiss="modal">
                    <span>&times;</span>
                    </button>
                </div>
                    <form id="editform" method="POST" enctype="" action="official-function.php">
                        <div class="row">
                            <input type="hidden" id="edit_id" name="edit_id">
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Full Name</strong></label>
                                <input type="text" class="form-control" placeholder="Enter full name" autocomplete="off" required="required" id="edit_fname" name="fnameedit">
                            </div>
                            <div class="col-md-5 mb-3">
                                <label><strong>Select Position</strong></label>
                                <select id="edit_position" name="positionedit" class="form-control">
                                    <option selected="selected" disabled="disabled">Select Position</option>
                                    <option value="Captain">CAPTAIN</option>
                                    <option value="Kagawad">KAGAWAD</option>  
                                    <option value="Secretary">SECRETARY</option>
                                    <option value="Treasurer">TREASURER</option>
                                    <option value="Book Keeper">BOOK KEEPER</option>
                                    <option value="SK Chairman">SK CHAIRMAN</option>                    
                                </select>
                            </div>
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Term Start</strong></label>
                                <input type="date" class="form-control" placeholder="enter term start" autocomplete="off" required="required" id="edit_start" name="startedit">
                            </div>
                            <div class="col-md-5 mb-3">
                                <label><strong>Term End</strong></label>
                                <input type="date" class="form-control" placeholder="enter term end" autocomplete="off" required="required" id="edit_end" name="endedit">
                            </div>
                            <div class="col-md-5 ml-5 mb-3">
                                <label><strong>Status</strong></label>
                                <select id="edit_status" name="statusedit" class="form-control">
                                    <option selected="selected" disabled="disabled">Select Status</option>
                                    <option value="Active">ACTIVE</option>
                                    <option value="Inactive">INACTIVE</option>                    
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                            <button type="submit" name="update_official" class="btn btn-success py-0">Update</button>
                            <button type="button" class="btn btn-danger py-0" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--delete official modal-->
        <div class="modal fade" id="OfficialDelmodal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header" style="background-color:navy;">
                    <h5 class="modal-title text-light" id="exampleModalLabel">Delete Official Record</h5>
                    <button type="button" class="close text-light" data-dismiss="modal">
                    <span>&times;</span>
                    </button>
                </div>
                    <form id="addform" method="POST" enctype="" action="official-function.php">
                        <div class="modal-body">
                            <input type="hidden" name="offID" id="delete_id">
                            <span><label style="font-size:25px">Are you sure, you want to delete this record?</label></span>
                            
                        </div>
                        <div class="modal-footer" style="background-color:navy;">
                            <button type="submit" name="delete_official" class="btn btn-danger py-0">Yes! Delete</button>
                            <button type="button" class="btn btn-secondary py-0" data-dismiss="modal">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--view official table-->
            <div class="table-container">
                <table class="officialtable table-bordered" id="officialtable" data-role="table" border="1" cellspacing="5">
            <thead class="table">
                <tr>
                    
                    <th scope="col">Name</th>
                    <th scope="col">Position</th>
                    <th scope="col">Term Start</th>
                    <th scope="col">Term End</th>
                    <th scope="col">Status</th>
                    <th scope="col">Operation</th>
                </tr>
            </thead>
            <tbody>
                        <?php
                            $conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");
                            $query = "SELECT * FROM officials";
                            $query_run = mysqli_query($conn, $query);
        
                            if(mysqli_num_rows($query_run) > 0)
                            {
                                foreach($query_run as $row)
                                {
                                    ?>
                                         <tr>
                                     <td class="officialId"><?php echo $row['full_name']; ?></td>
                                    <td><?php echo $row['position']; ?></td>
                                    <td><?php echo $row['term_start']; ?></td>
                                    <td><?php echo $row['term_end']; ?></td>
                                    <td><?php echo $row['term_status']; ?></td>
                                    <td>
                                        <a href="#" class="fas fa-eye text-success ml-4 view_btn" title="View"></a>
                                        <a href="#" class="fas fa-edit text-info edit_btn" title="Update"></a>
                                        <a href="#" class="fas fa-trash-alt text-danger delete_btn" title="Delete"></a>
                                    </td>
                                </tr>
        
                                    <?php
                                }
                            }
                            else
                            {
                                echo "<h5>No Record Found</h5>";
                            }
                            ?>
                        
                    </tbody>
        
                </table>
            </div>




    </div>
</div>

    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  
    <script>
        $(document).ready(function () {

            //read one official record
            $('.view_btn').click(function (e) {
                e.preventDefault();

                var officialId = $(this).closest('tr').find('.officialId').text();
                //console.log(officialId);

                $.ajax({
                    type: "POST",
                    url: "official-function.php",
                    data: {
                        'checking_viewbtn': true,
                        'full_name': officialId,
                    },
                    success: function(response) {
                        //console.log(response);
                        $('.official_viewing_data').html(response);
                        $('#OfficialViewmodal').modal('show');

                    }
                });

            });

            //update official record
            $('.edit_btn').click(function (e) {
                e.preventDefault();

                var officialId = $(this).closest('tr').find('.officialId').text();
                //console.log(officialId);

                $.ajax({
                    type: "POST",
                    url: "official-function.php",
                    data: {
                        'checking_edit_btn': true,
                        'full_name': officialId,
                    },
                    success: function(response) {
                        //console.log(response);
                        $.each(response, function(key, value){
                            //console.log(value['full_name']);

                            $('#edit_id').val(value['full_name']);
                            $('#edit_fname').val(value['full_name']);
                            $('#edit_position').val(value['position']);
                            $('#edit_start').val(value['term_start']);
                            $('#edit_end').val(value['term_end']);
                            $('#edit_status').val(value['term_status']);
                            $('#edit_user').val(value['username']);
                            $('#edit_pass').val(value['password']);

                        });



                        $('#OfficialEditmodal').modal('show');

                    }
                });

            });

            // delete official record
            $('.delete_btn').click(function (e){
                e.preventDefault();

                var officialId = $(this).closest('tr').find('.officialId').text();
                //console.log(officialId);
                $('#delete_id').val(officialId);
                $('#OfficialDelmodal').modal('show');

            });


        });
    </script>




    </body>
</html>