<?php
session_start();
$conn = mysqli_connect("127.0.0.1", "u938936141_root", "XAIxai_02", "u938936141_db_cap102");

if(isset($_POST['save_official']))
{
    $userName = $_SESSION['username'];
    
    // create official
    $fname = $_POST['fnameadd'];
    $position = $_POST['positionadd'];
    $tstart = $_POST['startadd'];
    $tend = $_POST['endadd'];
    $stat = $_POST['statusadd'];


    $query = "INSERT INTO officials (full_name,position,term_start,term_end,term_status) VALUES ('$fname','$position','$tstart','$tend','$stat')";

    $query_run = mysqli_query($conn, $query);

if ($query_run) {
    $_SESSION['status'] = "Successfully Saved!";
    header('Location: official-page.php');
} else {
    $_SESSION['status'] = "Not Saved: " . mysqli_error($conn); 
    header('Location: official-page.php');
}

$action = "Add Official"; 
    $timestamp = date("Y-m-d H:i:s");

    $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
    mysqli_query($conn, $logQuery);

}

// read offcial
if(isset($_POST['checking_viewbtn']))
{
    $o_id = $_POST['full_name'];
    //echo $return = $o_id;

    $query = "SELECT * FROM officials WHERE full_name='$o_id'";
    $query_run = mysqli_query($conn, $query);

    if(mysqli_num_rows($query_run) > 0)
    {
        foreach($query_run as $row)
        {
            echo $return = '
                <h5> Name : '.$row['full_name'].'</h5>
                <h5> Position : '.$row['position'].'</h5>
                <h5> Term Start : '.$row['term_start'].'</h5>
                <h5> Term End : '.$row['term_end'].'</h5>
                <h5> Status : '.$row['term_status'].'</h5>
            ';
        }
    }
    else
    {
        echo $return = "<h5>No Record Found</h5>";
    }
}



// update official
if(isset($_POST['checking_edit_btn']))
{
    
    $o_id = $_POST['full_name'];
    //echo $return = $o_id;
    $result_array = [];

    $query = "SELECT * FROM officials WHERE full_name='$o_id'";
    $query_run = mysqli_query($conn, $query);

    if(mysqli_num_rows($query_run) > 0)
    {
        foreach($query_run as $row)
        {
            array_push($result_array, $row);
            header('Content-type: application/json');
            echo json_encode($result_array);
        }
    }
    else
    {
        echo $return = "<h5>No Record Found</h5>";
    }
}


if(isset($_POST['update_official']))
{
    $userName = $_SESSION['username'];
    
    $off_id = $_POST['edit_id'];
    $fname = $_POST['fnameedit'];
    $position = $_POST['positionedit'];
    $tstart = $_POST['startedit'];
    $tend = $_POST['endedit'];
    $stat = $_POST['statusedit'];


    $query = "UPDATE officials SET full_name='$fname', position='$position', term_start='$tstart', term_end='$tend', term_status='$stat' WHERE full_name='$off_id'";
    $query_run = mysqli_query($conn, $query);

    if ($query_run) {
        $_SESSION['status'] = "Successfully Updated!";
        header('Location: official-page.php');
    } 
    else
    {
        $_SESSION['status'] = "Something went wrong!: " . mysqli_error($conn); 
        header('Location: official-page.php');
    }
    
    $action = "Update Official"; 
    $timestamp = date("Y-m-d H:i:s");

    $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
    mysqli_query($conn, $logQuery);
}

//delete official
if(isset($_POST['delete_official']))
{
    $userName = $_SESSION['username'];
    
    $offId = $_POST['offID'];
    $query = "DELETE FROM officials WHERE full_name='$offId' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Successfully Deleted!";
        header('Location: official-page.php');
    }
    else
    {
        $_SESSION['status'] = "Something went wrong!";
        header('Location: official-page.php');
    }
    
    $action = "Delete Official"; 
    $timestamp = date("Y-m-d H:i:s");

    $logQuery = "INSERT INTO history (username, action, timestamp) VALUES ('$userName', '$action', '$timestamp')";
    mysqli_query($conn, $logQuery);
}



?>